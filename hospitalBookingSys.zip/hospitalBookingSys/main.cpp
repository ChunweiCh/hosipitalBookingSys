#include <iostream>
#include <list>
#include <vector>
#include <string>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#include "CEdit.h"
#include "CTools.h"
#include "windowBase.h" 
#include "CTable.h"

//����
#include "CMainWin.h" 
#include "CLoginWin.h"
#include "CRoleSelectWin.h"
#include "CRegistWin.h"
#include "CAdminWin.h"
#include "CDoctorWin.h"
#include "CPatientWin.h" 
#include "CManageUserWin.h"
#include "CManageDoctorWin.h" 
#include "CManageDepartmentWin.h"
#include "CDoctorCenterWin.h"
#include "CDoctorMedicalConsultationWin.h" 
#include "CPatientCenterWin.h" 
#include "CPatientUpdateInfo.h" 
#include "CPatientChangePwdWin.h" 
#include "CPatientManageAppointmentWin.h" 
#include "CPatientStartBookingWin.h" 
#include "CBookingTime.h"
#include "CAddDoctorWin.h" 
#include "CStartAppointmentWin.h" 
#include "CPatientTreatmentWin.h"
#include "CEditDoctorWin.h"
#include "CRecordingWin.h"
#include "CPatientRecordWin.h"
//����
#include "CData.h"
#include "CUser.h"
#include "CDoctor.h"
#include "CPatient.h"




void proRun()
{	
	//ϵͳ���ݼ��� 
	//����Ա 
	CData::initAdmin();
	CData::initDoctor();
	CData::initPatient();
	CData::initAppointment();
	CData::initDepartment();
	//ԤԼʱ�� 
	CData::initBookingTime();
	//����ͬһ����������ָ��������
	WinBase* winArr[25] = {
		new CMainWin(0,0,40,16),
		new CLoginWin(0,0,40,20),
		new CRegistWin(0,0,40,20),
		new CAdminWin(0,0,50,20),
		new CDoctorWin(0,0,50,20),
		new CPatientWin(0,0,50,20),
		new CManageUserWin(0,0,60,24),
		new CManageDoctorWin(0,0,85,24),
		new CManageDepartmentWin(0,0,85,24),
		new CDoctorCenterWin(0,0,50,20),
		new CDoctorMedicalConsultationWin(0,0,60,24),
		new CPatientCenterWin(0,0,50,20),
		new CPatientUpdateInfoWin(0,0,50,22),
		new CPatientChangePwdWin(0,0,50,23),
		new CPatientManageAppointmentWin(0,0,60,20),
		new CPatientStartBookingWin(0,0,65,26),
		new CAddDoctorWin(0,0,52,33),
		new CStartAppointment(0,0,125,26),
		new CPatientTreatmentWin(0,0,115,26),
		new CEditDoctorWin(0,0,52,33),
		new CRecordingWin(0,0,52,22),
		new CPatientRecordWin(0,0,52,22)
	}; 
	
	int winIndex = 0;
	while(1)
	{
		winArr[winIndex]->showWin();
		winArr[winIndex]->winRun();
		winIndex = winArr[winIndex]->doAction();
		system("cls");
		
		if(winIndex == -1)
		break;
		
		
	}
	//�ͷ�����
	//���ڻ���ָ��
	for (int i=0; i<20;i++)
	{
		delete winArr[i];
	} 
	//�ͷ��û�����
	//����Ա 
	list<CUser*>::iterator it;
	for(it = CData::adminList.begin(); it != CData::adminList.end();++it)
	{
		delete(*it);
	}
	CData::adminList.clear();
	//ҽ��
	list<CDoctor*>::iterator it1;
	for(it1 = CData::doctorList.begin();it1 != CData::doctorList.end();++it1)
	{
		delete(*it1);
	 } 
	CData::doctorList.clear();
	//����
	list<CPatient*>::iterator it2;
	for(it2 = CData::patientList.begin(); it2 != CData::patientList.end();++it2)
	{
		delete(*it2);
	}
	CData::patientList.clear();
	//ԤԼ
	list<CAppointment*>::iterator it3;
	for(it3 = CData::appointmentList.begin(); it3 != CData::appointmentList.end();++it3)
	{
		delete(*it3);
	}
	CData::appointmentList.clear();
	//����
	vector<CDepartment*>::iterator it4;
	for(it4 = CData::deparmentVec.begin(); it4 != CData::deparmentVec.end();++it4)
	{
		delete(*it4);
	}
	CData::deparmentVec.clear();
	//ԤԼʱ��
	CData::currentYmdVec.clear();
	
	//ԤԼÿ��ʱ���
	CData::dayTimeHmdVec.clear();
	//��¼��ǰ�û���ԤԼ��Ϣ
	list<CAppointment*>::iterator it5;
	for(it5 = CData::nowUserAppointment.begin(); it5 != CData::nowUserAppointment.end();++it5)
	{
		delete(*it5);
	}
	CData::nowUserAppointment.clear(); 
	
}

void demo()
{	
	vector<string> docTableHead;
	CData::doctorList.push_back(new CDoctor(1001,"jason","123456",DOCTOR,"�����","����",SURGEON,""));
	CData::doctorList.push_back(new CDoctor(1002,"��ҽ��","123456",DOCTOR,"�����","����",SURGEON,""));
	CData::doctorList.push_back(new CDoctor(1003,"��ҽ��","123456",DOCTOR,"�����","����",SURGEON,""));
	CData::doctorList.push_back(new CDoctor(1004,"��ҽ��","123456",DOCTOR,"�����","����",SURGEON,""));
	CData::doctorList.push_back(new CDoctor(1005,"��ҽ��","123456",DOCTOR,"�����","����",SURGEON,""));
	docTableHead.push_back("ҽ��ID");
	docTableHead.push_back("ҽ������");
	docTableHead.push_back("  ְλ   ");
	docTableHead.push_back("��������");
	docTableHead.push_back("����ҽԺ");
	docTableHead.push_back("���");
	CTable* printTable = new CTable(5,5,0,0,"",TABLE,docTableHead);
	printTable->show(); 
	//printTable->showDoctorData(CData::doctorList); 
	printTable->showDoctorData(CData::doctorList);
	printTable->showPage(4,CData::doctorList.size());
	
}

void demo2()
{

 } 
int main(int argc, char** argv) {
	

	
	proRun();
	

	
	
	return 0;
}
