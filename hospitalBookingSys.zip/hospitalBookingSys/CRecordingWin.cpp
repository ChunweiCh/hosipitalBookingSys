#include "CRecordingWin.h"






// ҽ�������� --������Ϣ--�����¼ 
CRecordingWin::CRecordingWin(int x, int y, int w , int h)
:WinBase(x,y,w,h)
{	
	this->editFlag = editFlag;
	
	this->title = new CLabel(16,1,0,0,"�����¼����",LABEL);	
	this->noticeLabel = new CLabel(3,4,0,0,"",LABEL);
	this->timeShowLabel = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->patientIdLabel =  new CLabel(8,7,0,0,"�û�ID: ",LABEL);
	this->patientIdShow =  new CLabel(23,7,0,0,"",LABEL);
	this->appointmentPatientDesLabel = new CLabel(8,10,0,0,"ԤԼ����",LABEL);
	this->doctorDescriptionLabel = new CLabel(8,13,0,0,"��������",LABEL);
	
	this->appointmentPatientDesEdit = new CEdit(23,10,20,3,"",EDIT,15,1,4);
	this->doctorDescriptionEdit = new CEdit(23,13,20,4,"",EDIT,15,1,4);
	 
	this->confirmBtn = new CButton(10,18,10,3,"ȷ��",BUTTON);
	this->returnBtn = new CButton(25,18,10,3,"����",BUTTON);
	
	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	
	this->addCtrl(patientIdLabel);
	this->addCtrl(patientIdShow);
	this->addCtrl(appointmentPatientDesLabel);
	this->addCtrl(doctorDescriptionLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(appointmentPatientDesEdit);
	this->addCtrl(doctorDescriptionEdit);
	this->addCtrl(confirmBtn);//10
	this->addCtrl(returnBtn);//11

	
	
}

CRecordingWin::~CRecordingWin()
{
 
}


int CRecordingWin::doAction()
{	
	
	switch(this->ctrlIndex)
	{
		
		
		//������Ϣ 
		case 10:
			{
				this->editFlag = false;
				if(this->appointmentPatientDesEdit->getContent().empty()|| this->doctorDescriptionEdit->getContent().empty())
				{
					CTools::gotoxy(0,24);
					cout << "����������,������" << endl;
					getch();
					return RECORDINGWIN;
				}
				
				
				//�޸ĳɹ�
				CData::selectedAppointment->setSelfDescription(this->appointmentPatientDesEdit->getContent());
				CData::selectedAppointment->setDoctorDescription(this->doctorDescriptionEdit->getContent());
				CData::selectedAppointment->setAppointmentStatusInt( (AppointmentStatus)4);
				list<CAppointment*>::iterator it;
				for (it = CData::appointmentList.begin(); it !=CData::appointmentList.end(); ++it)
				{
					if(CData::selectedAppointment->getAppointmentId()==(*it)->getAppointmentId())
					{
						(*it) = CData::selectedAppointment;
						break;
					}
					
				} 
				
				//д���ļ�
				CData::updateAppointment();
				//��ʾ
				CTools::gotoxy(0,24);
				cout << "���³ɹ�" << endl;
				getch(); 
				
				//�༭����� 
				this->appointmentPatientDesEdit->EditClear();
				this->doctorDescriptionEdit->EditClear();
				return DOCTORMEDICALCONSULTATIONWIN;	
				
				
				
			}
			return DOCTORMEDICALCONSULTATIONWIN;
			
		//����
		case 11 :
			{	
			
				this->editFlag = false;
				//�༭����� 
				this->appointmentPatientDesEdit->EditClear();
				this->doctorDescriptionEdit->EditClear();
				return DOCTORMEDICALCONSULTATIONWIN;	
				
			}
			return DOCTORMEDICALCONSULTATIONWIN;
	}
	
} 


void CRecordingWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	if(CData::nowDoctor != NULL)
	{
		welcomeNotice += CData::nowDoctor->getUserName();
	} 
	welcomeNotice += ", ҽ��";
	this->noticeLabel->setContent(welcomeNotice);
	
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	
	this->patientIdShow->setContent(CData::selectedAppointment->getPatientPhoneNum());
	if(this->editFlag == false)
	{
		
		
		//��ʾ ҽ������
		this->appointmentPatientDesEdit->setContent(CData::selectedAppointment->getSelfDescription());
		this->doctorDescriptionEdit->setContent(CData::selectedAppointment->getDoctorDescription());
		
	}
	
	
	
	
	
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		
	
	
}
























