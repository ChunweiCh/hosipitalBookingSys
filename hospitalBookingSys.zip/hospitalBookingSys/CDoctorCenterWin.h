#ifndef _CDOCTORCENTERWIN_H_
#define _CDOCTORCENTERWIN_H_




#include "windowBase.h"
#include "ctrlBase.h"
#include "CData.h"


class CDoctorCenterWin: public WinBase 
{
	public:
		
	CDoctorCenterWin();
	CDoctorCenterWin(int x, int y, int w, int h);
	~CDoctorCenterWin();
	
	void showWin(); 
	int doAction();
		
	private:
	CLabel* title;
	CLabel* noticeLabel;
	CLabel* timeShowLabel;
	
	
	CButton* changePwdBtn;
	CButton* returnBtn;
 
		
	

	
}; 


#endif
