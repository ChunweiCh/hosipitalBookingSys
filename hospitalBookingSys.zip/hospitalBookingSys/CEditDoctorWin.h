#ifndef _CEDITDOCTORWIN_H_
#define _CEDITDOCTORWIN_H_

#include <vector> 
#include <string> 
#include "windowBase.h"
#include "ctrlBase.h"
#include "CData.h"

#include "CComboBox.h" 


class CEditDoctorWin : public WinBase
{
	public:
	CEditDoctorWin();
	CEditDoctorWin(int x, int y, int w, int h);
	~CEditDoctorWin();
	
	void showWin();
	int doAction();
		
		
		
		
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShowLabel;//���ڵ�ʱ��
	
	CLabel* doctorIdLabel;
	CLabel* doctorIdShow;
	CLabel* doctorNameLabel;
	CLabel* hospitalLabel;
	CLabel* hospitalShow;
	CLabel* departmentLabel;
	CLabel* doctorPosLabel;
	CLabel* doctorInfo;
	
	CLabel* departmentShowLabel;
	CLabel* doctorPosShow;
	
	CEdit* doctorNameEdit;
	
	CButton* departmentBtn;
	CButton* doctorPosBtn;
	CEdit* infoEdit;
	
	CButton* confirmBtn;
	CButton* returnBtn;
	//������ 
	vector<string> departmentVec;
	vector<string> docPosVec;
	
	int doctorNewId;
	//�ж��Ƿ��иı����� 
	bool editFlag; 
}; 



#endif
