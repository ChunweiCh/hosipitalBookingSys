#include "windowBase.h"






WinBase::WinBase(int x, int y, int width, int height)
{	
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	
	//��ʼ������
	for (int i=0; i<20; i++)
	{
		this->ctrlArr[i] = NULL;
	}	
	this->ctrlCount = 0;
	 
} 

WinBase::~WinBase()
{
	for (int i =0 ; i < this->ctrlCount;i++)
	{
		delete this->ctrlArr[i];
	}
}



void WinBase::addCtrl(CtrlBase* ctrlArr)
{
	this->ctrlArr[this->ctrlCount++] = ctrlArr;

	
}

int WinBase::getctrlIndex()
{
	return ctrlIndex; 
}

void WinBase::winRun()
{
	int i=0, key= 0;
	for (i=0;i<this->ctrlCount;i++)
	{
		if (this->ctrlArr[i]->getCtrlType() == EDIT)
		{
			CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),this->ctrlArr[i]->getY()+1);
			break;
		}
		else if (this->ctrlArr[i]->getCtrlType() == BUTTON)
		{
			CTools::gotoxy(this->ctrlArr[i]->getX()+3,this->ctrlArr[i]->getY()+1);
			break;
		}
		
		
	}
	//�ж����¼�
	while (1)
	{
		 key = CTools::getKey();
		 switch(key)
		 {
		 	case KEY_DOWN:
		 		i++;
		 		if(i == this->ctrlCount)i=0;
		 		while(1)
		 		{
		 			if(this->ctrlArr[i]->getCtrlType() == EDIT)
		 			{
		 				CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),this->ctrlArr[i]->getY()+1);
		 				break;
		 				
		 				
					}
					else if (this->ctrlArr[i]->getCtrlType() == BUTTON)
					{
						CTools::gotoxy(this->ctrlArr[i]->getX()+3,this->ctrlArr[i]->getY()+1);
						break;
					}
					i++;
					if(i==this->ctrlCount)i==0;
				}
				break;
			case KEY_UP:
			
				while(1)
		 		{
		 			i--;
					if(i==0)i=this->ctrlCount-1;
		 			if(this->ctrlArr[i]->getCtrlType() == EDIT)
		 			{
		 				CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),this->ctrlArr[i]->getY()+1);
		 				break;
		 				
		 				
					}
					else if (this->ctrlArr[i]->getCtrlType() == BUTTON)
					{
						CTools::gotoxy(this->ctrlArr[i]->getX()+3,this->ctrlArr[i]->getY()+1);
						break;
					}
					i--;
					if(i==0)i=this->ctrlCount;
				}		
				
				break;
//			case KEY_RIGHT:
//				while(1)
//				{
//					
//				}	
			case KEY_ENTER:
				if(this->ctrlArr[i]->getCtrlType()==BUTTON)
				{
						this->ctrlIndex = i;
						return;
				}	
				
			default:
					if(this->ctrlArr[i]->getCtrlType() == EDIT)
					{	
						//��������ķ���static_cast 
						static_cast<CEdit*>(ctrlArr[i])->editKeyListen((char)key);
						
					}
				
				
				break;
				
				
		 }
		 
		 
	 } 
	
	
}


void WinBase::showWin()
{
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

	
}


