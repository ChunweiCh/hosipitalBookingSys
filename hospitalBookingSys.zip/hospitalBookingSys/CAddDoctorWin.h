#ifndef _CADDDOCTORWIN_H_
#define _CADDDOCTORWIN_H_

#include <vector> 
#include <string> 
#include "windowBase.h"
#include "ctrlBase.h"
#include "CData.h"

#include "CComboBox.h" 


class CAddDoctorWin : public WinBase
{
	public:
	CAddDoctorWin();
	CAddDoctorWin(int x, int y, int w, int h);
	~CAddDoctorWin();
	
	void showWin();
	int doAction();
		
		
		
		
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShowLabel;//���ڵ�ʱ��
	
	CLabel* doctorIdLabel;
	CLabel* doctorIdShow;
	CLabel* doctorNameLabel;
	CLabel* hospitalLabel;
	CLabel* hospitalShow;
	CLabel* departmentLabel;
	CLabel* doctorPosLabel;
	CLabel* doctorInfo;
	
	CLabel* departmentShowLabel;
	CLabel* doctorPosShow;
	
	CEdit* doctorNameEdit;
	
	CButton* departmentBtn;
	CButton* doctorPosBtn;
	CEdit* infoEdit;
	
	CButton* confirmBtn;
	CButton* returnBtn;
	//������ 
	vector<string> departmentVec;
	vector<string> docPosVec;
	
	int doctorNewId;
	
	
}; 



#endif
