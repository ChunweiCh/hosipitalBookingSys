#ifndef _CREGISTWIN_H_
#define _CREGISTWIN_H_

#include<iostream> 

#include "CData.h"
#include "windowBase.h"
#include "ctrlBase.h"

using namespace std;

class CRegistWin : public WinBase
{
	public:
		CRegistWin();
		CRegistWin(int x, int y , int w , int h);
		~CRegistWin();
		 
		
		int doAction();
		
		
	private:
		CLabel* title;
		CLabel* phoneNumLabel;
		CLabel* verficationCodeLabel;
		CLabel* verificationShow;
		
		//EDIT
		CEdit* phoneNumEdit;
		CEdit* verficationCodeEdit;
		
		//BUTTON
		CButton* getVerficationCodeBtn;
		CButton* confirmBtn;
		CButton* returnBtn;		
		
		string nowPhone; 
		string verification;
	protected:

	
};























#endif
