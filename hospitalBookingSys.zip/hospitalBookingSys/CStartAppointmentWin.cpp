#include "CStartAppointmentWin.h"



//���������� --ȡ�Ž��� 
CStartAppointment::CStartAppointment(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->findAppointmentMember = findAppointmentMember;
	this->title = new CLabel(46,1,0,0,"ȡ�Ž���",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ,��ͨ�û�",LABEL);
	this->timeShowLabel = new CLabel(58,4,0,0,"����: ",LABEL);
	this->enterUserIdNoticeLabel = new CLabel(5,7,0,0,"�������������: ",LABEL);
	this->upDownPageNoticeLabel = new CLabel(95,19,0,0,"�� �� �� ��ҳ",LABEL);
	
	this->frontDateEdit = new CEdit(25,7,20,3,"",EDIT,15,1,3);
	this->orLabel = new CLabel(47,7,0,0,"��",LABEL);
	this->endDateEdit = new CEdit(52,7,20,3,"",EDIT,15,1,3);
	
	
	

	
	this->searchBtn = new CButton(74,7,10,3,"��ѯ",BUTTON);
	//��ͷ
	this->tableHead = tableHead;
	tableHead.push_back("    ԤԼ���    ");//ID 
	tableHead.push_back("   ԤԼʱ��   ");
	tableHead.push_back("  ԤԼ����ʱ��");
	tableHead.push_back("ԤԼҽԺ");
	tableHead.push_back("ԤԼ����");
	tableHead.push_back("ԤԼҽ��");
	tableHead.push_back("����״̬");
	
	
	
	
	
	this->appointmentTable = new CTable(10,10,0,0,"",TABLE,this->tableHead); 
	
	this->row1Btn = new CButton(5,12,0,0,"",BUTTONDYNAMIC);
	this->row2Btn = new CButton(5,14,0,0,"",BUTTONDYNAMIC);
	this->row3Btn = new CButton(5,16,0,0,"",BUTTONDYNAMIC);
	this->returnBtn = new CButton(10,19,10,3,"����",BUTTON); 
	
	this->addCtrl(title); 
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(enterUserIdNoticeLabel);
	this->addCtrl(upDownPageNoticeLabel);
	
	this->addCtrl(frontDateEdit); //5
	this->addCtrl(orLabel);
	this->addCtrl(endDateEdit);
	

	this->addCtrl(searchBtn); //8
	this->addCtrl(appointmentTable);
	
	this->addCtrl(row1Btn);//10
	this->addCtrl(row2Btn);//11
	this->addCtrl(row3Btn);//12
	this->addCtrl(returnBtn); //13
	
	
}




CStartAppointment::~CStartAppointment()
{
	
}
	
int CStartAppointment::doAction()
{
	switch(this->ctrlIndex)
	{
		//��ѯ 
		case 8:
			{
				string  frontDateInput = this->frontDateEdit->getContent();
				string  endDateInput = this->endDateEdit->getContent();
				
				//������֤
				if(frontDateInput.empty() || endDateInput.empty())
				{
					 CTools::gotoxy(0,28);
					 cout << "�������������ݽ�������,���������롣��ʽΪYYYYMMDD,20251022" << endl;
					 getch();
					  //����༭��
					 this->frontDateEdit->EditClear();
					 this->endDateEdit->EditClear(); 
					 return STARTAPPOINTMENTWIN; 
				} 
				else if(!CTools::isValiInputDate(frontDateInput)|| !CTools::isValiInputDate(endDateInput))
				{
					CTools::gotoxy(0,28);
					 cout << "���ڸ�ʽ����,��ʹ��YYYYMMDD,20250712" << endl;
					 getch();
					 //����༭��
					 this->frontDateEdit->EditClear();
					 this->endDateEdit->EditClear(); 
					  
					 return STARTAPPOINTMENTWIN; 
				}
				else if(frontDateInput > endDateInput)
				{
					CTools::gotoxy(0,28);
					 cout << "��ʼ���ڲ������ڽ�������" << endl;
					 getch();
					 //����༭��
					 this->frontDateEdit->EditClear();
					 this->endDateEdit->EditClear(); 
					  
					 return STARTAPPOINTMENTWIN; 
				}
				
				
				//ÿ�����ض�Ҫ���findmember������
				
				this->findAppointmentMember.clear();
				
				list<CAppointment*>::iterator it;
				for(it = CData::nowUserAppointment.begin(); it != CData::nowUserAppointment.end();++it)
				{	 
					string chineseDate = (*it)->getAppointmentTime();
					string appointmentDate = CTools::chineseDateToNumber(chineseDate);//ת�ɴ����� 
					if(appointmentDate.empty()) continue;
					//�ж������Ƿ����м� 
					if(appointmentDate >= frontDateInput && appointmentDate <= endDateInput)
					{
						findAppointmentMember.push_back(*it);
					}
					 
				}
				//��ѯ�ж�
				if(findAppointmentMember.empty())
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->appointmentTable->setPageIndex(1);
					
					CTools::gotoxy(0,28);
					cout << "û���ҵ�" + frontDateInput + "��" + endDateInput + "֮���ԤԼ" << endl;
					getch();
					
					
					//����༭��
					 this->frontDateEdit->EditClear();
					 this->endDateEdit->EditClear(); 
					  
					 return STARTAPPOINTMENTWIN; 
				}
				else 
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->appointmentTable->setPageIndex(1);
					return STARTAPPOINTMENTWIN; 
				}
				
			}
			
		
	
		//��һ�а�ť 
		case 10:
		//�ڶ��а�ť 
		case 11:
		//�����а�ť 	
		case 12: 
		{
			 // ȷ����ǰ��ʾ������Դ
		    list<CAppointment*>& currentList = this->findAppointmentMember.empty() 
		                                ? CData::appointmentList 
		                                : this->findAppointmentMember;
		    // ǿ�����÷�ҳ��������ȫ��ʩ��
			    if(this->appointmentTable->getPageIndex() <= 0) {
			        this->appointmentTable->setPageIndex(1);
			    }
		    // ��ȡ��ǰҳ��3��ҽ������
		    list<CAppointment*> currentPageAppointment = this->appointmentTable->getCurrentPageAppointment(currentList);/////////
		    
		    // ����ѡ�е������� (9��0, 10��1, 11��2)
		    int selectedRow = this->ctrlIndex - 10;
		    
		    // ��ȡѡ�е�ҽ��
		    list<CAppointment*>::iterator it = currentPageAppointment.begin();
		    advance(it, selectedRow);
		    
		    if (it != currentPageAppointment.end() && *it != NULL) 
			{	
				CData::selectedAppointment = NULL;
				list<CAppointment*>::iterator it2;
				for(it2 = CData::appointmentList.begin(); it2 != CData::appointmentList.end(); ++it2)
				{	
					if((*it2)->getAppointmentId() == (*it)->getAppointmentId())
					{
						CData::selectedAppointment = *it2;
						break;
					} 
						
				} 
		        if(!CData::selectedAppointment)
		        {//����δ�ҵ������ 
		        	return STARTAPPOINTMENTWIN;
				}
		        
		        //ҵ���߼�  ȡ������ ��  ԤԼ�ɹ�
				WinBase* notice = new CAddorCannelAppointment(40,9,48,15); 
		        notice->showWin();
		        notice->winRun(); 
		        int noticeResult = notice->doAction();
		        delete notice;
		        switch(noticeResult)
		        {	//	ȡ�� 
		        	case 1:
		        		{	//�����ݵ������ļ�
							//�޸�״̬--������ 
		        			
		        			if(CData::selectedAppointment->getAppointmentStatusInt()==1 )
		        			{
		        				CData::selectedAppointment->setAppointmentStatusInt((AppointmentStatus)2);
		        				//��������
								CData::updateAppointment();
							}
							else 
							{
								CTools::gotoxy(0,28);
								cout << "��ԤԼ��ȷ״̬�ĵ���" << endl;
							    getch();
								return STARTAPPOINTMENTWIN;	
							}
		        			
		        			
							//��ʾ�� ȡ�ųɹ���
							string noticeTemp = "ȡ�ųɹ�"; 
							WinBase* worked = new CSimpleNotice(40,9,48,15,noticeTemp); 
							worked->showWin();
							worked->winRun();
							int result = worked->doAction();
							delete worked;
							
							switch(result)
							{
								case 1: 
									return STARTAPPOINTMENTWIN;
									
							}
		        			
		        			return STARTAPPOINTMENTWIN;	
						}
		        		 
		        	//ȡ�� 
					case 2:
		        		{	
		        			string a1 =CData::selectedAppointment->getAppointmentTime();
		        			string b1 = CTools::getCurrentTime();
		        			string appointmentTime = CTools::chineseDateToNumber(a1);
		        			string currentTime = CTools::chineseDateToNumber(b1);
		        			int a = atoi(appointmentTime.c_str());
		        			int b = atoi(currentTime.c_str());
		        			
		        			if( a-b >= 0 && a-b<=2 && CData::selectedAppointment->getAppointmentStatusInt()==1&&
							!appointmentTime.empty() && !currentTime.empty())
							{//�ɹ�ȡ������
							 CData::selectedAppointment->setAppointmentStatusInt((AppointmentStatus)3);
							
							 //д���ļ� ����״̬
							 CData::updateAppointment();
							 
							 list<CAppointment*>::iterator it;
							 for(it = CData::appointmentList.begin(); it != CData::appointmentList.end(); ++it)
							 {
							 	if(CData::selectedAppointment->getAppointmentId() == (*it)->getAppointmentId())
							 	{
							 		(*it)->setAppointmentStatusInt((AppointmentStatus)3);
							 		
							 		break;
								}
							 	
							 }
							 
							this->showWin();
							CTools::gotoxy(0,28);
							cout << "ȡ��ԤԼ�ɹ�" << endl;
							getch(); 
							return STARTAPPOINTMENTWIN;
							}
							else
							{
								CTools::gotoxy(0,28);
								cout << "ȡ��ԤԼʧ��" << endl;
							    getch();
								return STARTAPPOINTMENTWIN;							
							
							} 
		        			//
		        			
						}
					//���� 
					case 3:
						return STARTAPPOINTMENTWIN;	
		        
					
				}
		       

		    }
		    
					
			
			
			
		}
		
		//����	
		case 13:
			{ 
				//����༭��
			 this->frontDateEdit->EditClear();
			 this->endDateEdit->EditClear(); 
				this->appointmentTable->setPageIndex(1);
				return PATIENTWIN;
			}
		case -2:
			return STARTAPPOINTMENTWIN;
	}
	
	
	
}
	
void CStartAppointment::showWin()
{
	
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		
	
	
	if(this->findAppointmentMember.empty())
	{
		this->appointmentTable->showAppointmentData(CData::nowUserAppointment);	
		this->appointmentTable->showPage(3,CData::nowUserAppointment.size());
	}
	else
	{
		this->appointmentTable->showAppointmentData(this->findAppointmentMember);	
		this->appointmentTable->showPage(3,this->findAppointmentMember.size());
	}	

}


void CStartAppointment::winRun()
{
    int i=0, key= 0;
  
    
    // �ҵ���ʼ�۽��Ŀؼ�
    for (i=0; i<this->ctrlCount; i++)
    {
        if (this->ctrlArr[i]->getCtrlType() == EDIT)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                          this->ctrlArr[i]->getY()+1);
            break;
        }
        else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                 this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
            // Set arrow immediately for dynamic buttons
            if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
            {
                static_cast<CButton*>(this->ctrlArr[i])->setContent("��");
                this->ctrlArr[i]->show();
                
            }
            break;
        }
    }
    
    // ���浱ǰ�۽����а�ťָ��
    CButton* currentRowBtn = NULL;
    if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
    {
        currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
    }
    // ������������ 
    while (1)
    {
        key = CTools::getKey();
        switch(key)
        {
            case KEY_DOWN:
            {	
            	// �����ǰ�а�ť�ļ�ͷ
                if (currentRowBtn != NULL)
                {
                    currentRowBtn->setContent("");
                    currentRowBtn->show();
                    currentRowBtn = NULL;
                }
                
                i++;
                if (i == this->ctrlCount) i = 0;
                
                while(1)
                {
                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
                    {	
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                                      this->ctrlArr[i]->getY()+1);
                        break;
                    }
                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
                    {
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
                        // ������а�ť����ʾ��ͷ
                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
                        {
                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
                            currentRowBtn->setContent("��");
                            currentRowBtn->show();
                            showWin();
                        }
                        break;
                    }
                    i++;
                    if (i == this->ctrlCount) i = 0;
                }
                break;
			}
				    
                
                
            case KEY_UP:
                {	
                	// �����ǰ�а�ť�ļ�ͷ
	                if (currentRowBtn != NULL)
	                {
	                    currentRowBtn->setContent("");
	                    currentRowBtn->show();
	                    currentRowBtn = NULL;
	                }
                	i--;
	                if (i < 0) i = this->ctrlCount - 1;
	                
	                while(1)
	                {
	                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
	                                      this->ctrlArr[i]->getY()+1);
	                        break;
	                    }
	                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
	                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
	                         // ������а�ť����ʾ��ͷ
	                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
	                        {
	                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
	                            currentRowBtn->setContent("��");
	                            currentRowBtn->show();
	                            showWin();
	                        }
	                        
	                        break;
	                    }
	                    i--;
	                    if (i < 0) i = this->ctrlCount - 1;
	                }
	                break;
				}
                
                
                
            case KEY_RIGHT:
            	{
            		this->appointmentTable->showNextPage();
	                this->ctrlIndex = -2;
	                return;
				}
                
                
            case KEY_LEFT:
                this->appointmentTable->showLastPage();
                this->ctrlIndex = -2;
                return;
                
            case KEY_ENTER:
            	{	
            		if(currentRowBtn) 
					{
					    currentRowBtn->setContent("");  // �����ͷ
					    currentRowBtn->show();
					}
            		if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                    this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                {
	                    this->ctrlIndex = i;
	                    return;
	                }
	                
	                break;
				}
                
                
            default:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                {    
	                    static_cast<CEdit*>(ctrlArr[i])->editKeyListen((char)key);
	                }
	                break;
				}
                
        }
    }
}
















