#include "CManageUserWin.h"

CManageUserWin::CManageUserWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->findMember = findMember;
	this->title = new CLabel(26,1,0,0,"�û���������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ, admin, ����Ա",LABEL);
	this->timeShowLabel = new CLabel(38,4,0,0,"����: ",LABEL);
	this->enterUserIdNoticeLabel = new CLabel(5,7,0,0,"�������û��˺�: ",LABEL);
	this->upDownPageNoticeLabel = new CLabel(37,19,0,0,"�� �� �� ��ҳ",LABEL);
	
	this->enterUserIdEdit = new CEdit(25,7,20,3,"",EDIT,11,1,0);
	
	this->searchBtn = new CButton(47,7,10,3,"��ѯ",BUTTON);
	//��ͷ 
	this->tableHead = tableHead;
	tableHead.push_back("    �˺�    "); 
	tableHead.push_back("     ������Ϣ     ");
	this->patientTable = new CTable(10,10,0,0,"",TABLE,tableHead);
	
	this->returnBtn = new CButton(6,19,10,3,"����",BUTTON); 
	
	this->addCtrl(title); 
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(enterUserIdNoticeLabel);
	this->addCtrl(upDownPageNoticeLabel);
	this->addCtrl(enterUserIdEdit);
	this->addCtrl(searchBtn); //6
	this->addCtrl(patientTable);//7
	this->addCtrl(returnBtn); //8
	
	
}




CManageUserWin::~CManageUserWin()
{
	
}
	
int CManageUserWin::doAction()
{
	switch(this->ctrlIndex)
	{
		//��ѯ 
		case 6:
			{
				string phoneNum = this->enterUserIdEdit->getContent();
				//ÿ�����ض�Ҫ���findmember������
				
				this->findMember.clear();
				list<CPatient*>::iterator it;
				for(it = CData::patientList.begin(); it != CData::patientList.end();++it)
				{
					string patientPhone = (*it)->getPhoneNum();
					if(patientPhone.find(phoneNum)!= string::npos)
					{
						findMember.push_back(*it);
					}
					 
				}
				//��ѯ�ж�
				if(findMember.empty())
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->patientTable->setPageIndex(1);
					
					this->enterUserIdEdit->setContent("δ�ҵ��������");
					this->enterUserIdEdit->show();
					getch();
					this->enterUserIdEdit->setContent("");
					this->enterUserIdEdit->show();
					return MANAGEUSERWIN;
				}
				else 
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->patientTable->setPageIndex(1);
					return MANAGEUSERWIN;
				}
				
			}
			
		//����	
		case 8:
			{	
				
				this->enterUserIdEdit->EditClear();
				this->findMember.clear();
				this->patientTable->setPageIndex(1);
			}
			return ADMINWIN;
		//��ҳ���ر����� 
		case -2:
			return MANAGEUSERWIN; 
	}
	
	
	
}
	
void CManageUserWin::showWin()
{
	
	
	
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
	 
	if(this->findMember.empty())
	{
		this->patientTable->showPatientData(CData::patientList);	
		this->patientTable->showPage(3,CData::patientList.size());
	}
	else
	{
		this->patientTable->showPatientData(this->findMember);	
		this->patientTable->showPage(3,this->findMember.size());
	}
	
	
}

void CManageUserWin::winRun()
{
		int i=0, key= 0;
	for (i=0;i<this->ctrlCount;i++)
	{
		if (this->ctrlArr[i]->getCtrlType() == EDIT)
		{
			CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),this->ctrlArr[i]->getY()+1);
			break;
		}
		else if (this->ctrlArr[i]->getCtrlType() == BUTTON)
		{
			CTools::gotoxy(this->ctrlArr[i]->getX()+3,this->ctrlArr[i]->getY()+1);
			break;
		}
		
		
	}
	//�ж����¼�
	while (1)
	{
		 key = CTools::getKey();
		 switch(key)
		 {
		 	case KEY_DOWN:
		 		i++;
		 		if(i == this->ctrlCount)i=0;
		 		while(1)
		 		{
		 			if(this->ctrlArr[i]->getCtrlType() == EDIT)
		 			{
		 				CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),this->ctrlArr[i]->getY()+1);
		 				break;
		 				
		 				
					}
					else if (this->ctrlArr[i]->getCtrlType() == BUTTON)
					{
						CTools::gotoxy(this->ctrlArr[i]->getX()+3,this->ctrlArr[i]->getY()+1);
						break;
					}
					i++;
					if(i==this->ctrlCount)i==0;
				}
				break;
			case KEY_UP:
			
				while(1)
		 		{
		 			i--;
					if(i==0)i=this->ctrlCount-1;
		 			if(this->ctrlArr[i]->getCtrlType() == EDIT)
		 			{
		 				CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),this->ctrlArr[i]->getY()+1);
		 				break;
		 				
		 				
					}
					else if (this->ctrlArr[i]->getCtrlType() == BUTTON)
					{
						CTools::gotoxy(this->ctrlArr[i]->getX()+3,this->ctrlArr[i]->getY()+1);
						break;
					}
					i--;
					if(i==0)i=this->ctrlCount;
				}		
				
				break;
			case KEY_RIGHT:
				{
					this->patientTable->showNextPage();
					this->ctrlIndex = -2;
					return;
				}	
				
			case KEY_LEFT:
				{
					this->patientTable->showLastPage();
					this->ctrlIndex = -2;
					return;  
				}	
			case KEY_ENTER:
				if(this->ctrlArr[i]->getCtrlType()==BUTTON)
				{
						this->ctrlIndex = i;
						return;
				}	
				
			default:
					if(this->ctrlArr[i]->getCtrlType() == EDIT)
					{	
						//��������ķ���static_cast 
						static_cast<CEdit*>(ctrlArr[i])->editKeyListen((char)key);
						
					}
				
				
				break;
				
				
		 }
		 
		 
	 } 
}



















