#ifndef _CEIDT_H
#define _CEIDT_H

#include "CTools.h"
#include <cstring>
#include <iostream>
#include <string>
using namespace std;

#include "ctrlBase.h"
class CEdit: public CtrlBase
{
	public:
	CEdit(int x, int y, int width, int height, string content,CONTROL ctrlType, int maxlen, int mode, int inputType);
	~CEdit();

	int getMaxlen();
	int getMode();
	int getInputType();
	
	//��ձ༭��
	void EditClear(); 
	//��������
	void editKeyListen(char ch); 
	void show();
	private: 
		int inputType;
		int maxlen;
		int mode; 
		
		
		

};








#endif
