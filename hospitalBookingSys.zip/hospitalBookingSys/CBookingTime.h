#ifndef _CBOOKINGTIME_H_
#define _CBOOKINGTIME_H_

#include "CTools.h"
#include <vector>
class CBookingTime
{
	public:

		
	static vector<string> currentYmdVec;
	static vector<string> dayTimeHmdVec;
	



	
	
		
};


#endif
