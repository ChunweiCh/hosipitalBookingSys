#include "CAddDoctorWin.h"




CAddDoctorWin::CAddDoctorWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->doctorNewId = 0; 
	
	this->title = new CLabel(16,1,0,0,"����ҽ������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ, admin, ����Ա",LABEL);
	this->timeShowLabel = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->doctorIdLabel = new CLabel(8,7,0,0,"ҽ��ID: ",LABEL);
	this->doctorIdShow = new CLabel(21,7,0,0,"",LABEL);
	 
	this->doctorNameLabel = new CLabel(8,10,0,0,"ҽ������: ",LABEL); 
	this->hospitalLabel = new CLabel(8,13,0,0,"����ҽԺ: ",LABEL); 
	this->hospitalShow = new CLabel(21,13,20,3,"����ҽԺ",LABEL); 
	this->departmentLabel = new CLabel(8,16,0,0,"��������: ",LABEL);  	
	this->doctorPosLabel =new CLabel(8,19,0,0,"ҽ��ְλ: ",LABEL);  
	this->doctorInfo = new CLabel(8,22,0,0,"��    ��: ",LABEL); 
	
	//��
	this->departmentShowLabel =  new CLabel(21,16,20,3,"",LABEL);
	this->doctorPosShow = new CLabel(21,19,20,3,"",LABEL);
	
	
	this->doctorNameEdit = new CEdit(21,10,20,3,"",EDIT,10,1,4); 
 	
	this->departmentBtn = new CButton(35,16,0,0,"��",BUTTON);//14
	this->doctorPosBtn = new CButton(35,19,0,0,"��",BUTTON);//15
	
	this->infoEdit = new CEdit(21,22,20,5,"",EDIT,30,1,4);
	
	this->confirmBtn = new CButton(10,28,10,3," ȷ�� ",BUTTON);//17
	
	this->returnBtn = new CButton(27,28,10,3," ���� ",BUTTON);//18
	
	//������ 
	this->departmentVec = departmentVec;
	departmentVec.push_back("������");
	departmentVec.push_back("�����");
	departmentVec.push_back("���");
	departmentVec.push_back("�ڿ�");
	this->docPosVec = docPosVec;
	docPosVec.push_back("ʵϰ");
	docPosVec.push_back("����");
	docPosVec.push_back("����");
	docPosVec.push_back("���");
	docPosVec.push_back("�ڿ�");
	 
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(doctorIdLabel);
	this->addCtrl(doctorIdShow);
	this->addCtrl(doctorNameLabel);
	this->addCtrl(hospitalLabel);
	this->addCtrl(hospitalShow);
	this->addCtrl(departmentLabel);
	this->addCtrl(doctorPosLabel);
	this->addCtrl(doctorInfo);
	this->addCtrl(departmentShowLabel);
	this->addCtrl(doctorPosShow);
	this->addCtrl(doctorNameEdit);
	this->addCtrl(departmentBtn);
	this->addCtrl(doctorPosBtn);
	this->addCtrl(infoEdit);
	this->addCtrl(confirmBtn);
	this->addCtrl(returnBtn);

	
}


CAddDoctorWin::~CAddDoctorWin()
{
	
}




void CAddDoctorWin::showWin()
{
		
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	//ID������ʾ
	this->doctorNewId = CData::doctorList.empty()?1001: CData::doctorList.back()->getId()+1;
	string doctorNewIdString = "D" + CTools::intToString(doctorNewId);
	
	this->doctorIdShow->setContent(doctorNewIdString);
	
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 
		
	}
}



int CAddDoctorWin::doAction()
{
	switch(this->ctrlIndex)
	{
		
		//���������� 
		case 14:
			{
				WinBase* departmentComboBox = new CComboBox(21,21,20,0,this->departmentVec);
				departmentComboBox->showWin();
				departmentComboBox->winRun();
				int departmentResult = departmentComboBox->doAction();
				delete departmentComboBox;
				switch(departmentResult)
				{
					case 1: this->departmentShowLabel->setContent(this->departmentVec[0]);
							return ADDDOCTORWIN;
					case 2: this->departmentShowLabel->setContent(this->departmentVec[1]);
							return ADDDOCTORWIN;
					case 3: this->departmentShowLabel->setContent(this->departmentVec[2]);
							return ADDDOCTORWIN;
					case 4: this->departmentShowLabel->setContent(this->departmentVec[3]);
							return ADDDOCTORWIN;
				}
				
				 
			} 
			return ADDDOCTORWIN;
		//ҽ��ְλ������ 
		case 15:
			{
				WinBase* docPosComboBox = new CComboBox(21,19,20,0,this->docPosVec);
				docPosComboBox->showWin();
				docPosComboBox->winRun();
				int docPosReuslt = docPosComboBox->doAction();
				delete docPosComboBox;
				switch(docPosReuslt)
				{
					case 1: this->doctorPosShow->setContent(this->docPosVec[0]);
							return ADDDOCTORWIN;
					case 2: this->doctorPosShow->setContent(this->docPosVec[1]);
							return ADDDOCTORWIN;
					case 3: this->doctorPosShow->setContent(this->docPosVec[2]);
							return ADDDOCTORWIN;
					case 4: this->doctorPosShow->setContent(this->docPosVec[3]);
							return ADDDOCTORWIN;
					case 5: this->doctorPosShow->setContent(this->docPosVec[4]);
							return ADDDOCTORWIN;
				}
				
			}
			return ADDDOCTORWIN;
		//ȷ�� 
		case 17:
			{
				if(this->doctorNameEdit->getContent().empty() || this->departmentShowLabel->getContent().empty()|| this->doctorPosShow->getContent().empty()
				|| this->infoEdit->getContent().empty())
				{
					CTools::gotoxy(0,34);
					cout << "������������������" << endl;
					getch();
					return ADDDOCTORWIN; 
				}
				//ҽ��ְλת��
				int doctorPosEnum = 0; // Ĭ��ֵ������Ϊ-1��ʾ��Ч��
				std::string posStr = this->doctorPosShow->getContent();
				
				if (posStr == "ʵϰ") {
				    doctorPosEnum = 5;
				} else if (posStr == "����") {
				    doctorPosEnum = 1;
				} else if (posStr == "����") {
				    doctorPosEnum = 2;
				} else if (posStr == "���") {
				    doctorPosEnum = 3;
				} else if (posStr == "�ڿ�") {
				    doctorPosEnum = 4;
				} else {
				    // ����δְ֪λ�������׳��쳣������Ĭ��ֵ��
				    doctorPosEnum = 0; // �� -1 ��ʾ��Ч
				}
				
				//���ӳɹ�
				CData::doctorList.push_back(new CDoctor(this->doctorNewId,this->doctorNameEdit->getContent(),"123456",DOCTOR,this->departmentShowLabel->getContent(),
				this->infoEdit->getContent(),(DocPosition)doctorPosEnum,this->hospitalLabel->getContent())); 
		
				//д���ļ�
				CData::addDoctor(CData::doctorList.back());
				//��ʾ
				CTools::gotoxy(0,34);
				cout << "���ӳɹ�" << endl;
				getch();
				
				//�༭����� 
				this->doctorNameEdit->EditClear();
				this->departmentShowLabel->setContent("");
				this->doctorPosShow->setContent("");
				this->infoEdit->EditClear(); 
				return MANAGEDOCTORWIN;	
				
				
				 
					
			}
			
			//���� 
		case 18:
			{
				//�༭����� 
				this->doctorNameEdit->EditClear();
				this->departmentShowLabel->setContent("");
				this->doctorPosShow->setContent("");
				this->infoEdit->EditClear(); 
				return MANAGEDOCTORWIN;	
			}
			
		
	}
}


















