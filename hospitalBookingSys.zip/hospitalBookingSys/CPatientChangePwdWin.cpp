#include "CPatientChangePwdWin.h"




CPatientChangePwdWin::CPatientChangePwdWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(16,1,0,0,"�޸��������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ,��ͨ�û�",LABEL);
	this->timeShow = new CLabel(28,4,0,0,"����: ",LABEL);
		
	this->phoneNumLabel = new CLabel(11,7,0,0,"�ֻ�����: ",LABEL);
	this->phoneNumShow = new CLabel(21,7,0,0,"",LABEL);
	this->oldPwdLabel = new CLabel(11,10,0,0,"ԭ����: ",LABEL);
	this->newPwdLabel = new CLabel(11,13,0,0,"������: ",LABEL);
	this->confirmNewPwdLabel = new CLabel(11,16,0,0,"ȷ������: ",LABEL);
	
	this->oldPwdEdit = new CEdit(21,10,20,3,"",EDIT,6,0,0);
	this->newPwdEdit = new CEdit(21,13,20,3,"",EDIT,6,0,0);
	this->confirmNewPwdEdit = new CEdit(21,16,20,3,"",EDIT,6,0,0);
	
	this->confirmBtn = new CButton(14,19,10,3," ȷ�� ",BUTTON);
	this->returnBtn = new CButton(27,19,10,3," ���� ",BUTTON);
	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShow);
	this->addCtrl(phoneNumLabel);
	this->addCtrl(phoneNumShow);
	this->addCtrl(oldPwdLabel);
	this->addCtrl(newPwdLabel);
	this->addCtrl(confirmNewPwdLabel);
	this->addCtrl(oldPwdEdit);
	this->addCtrl(newPwdEdit);
	this->addCtrl(confirmNewPwdEdit);
	this->addCtrl(confirmBtn);//11
	this->addCtrl(returnBtn);//12



}


CPatientChangePwdWin::~CPatientChangePwdWin()
{
	
}




CPatientChangePwdWin::doAction()
{

	switch(this->ctrlIndex)
	{	//ȷ�� 
		case 11:
			{
				if(this->oldPwdEdit->getContent() != CData::nowUser->getPwd())
				{
					
					CTools::gotoxy(0,24);
					cout << "������������³���" << endl;
					getch();
					
					
					return PATIENTCHANGEPWDWIN;
					
				} 
				else if(this->newPwdEdit->getContent() != this->confirmNewPwdEdit->getContent() || this->newPwdEdit->getContent().size()!=6)
				{
					CTools::gotoxy(0,24);
					cout << "ȷ�������������벻һ�»�����6λ���������³���" << endl;
					getch();
					
					
					return PATIENTCHANGEPWDWIN;
				}
				//�޸�����ɹ���������
				CData::nowUser->setPwd(newPwdEdit->getContent());
				list<CPatient*>::iterator it;
					for(it = CData::patientList.begin(); it != CData::patientList.end();++it)
					{
						if(CData::nowUser->getId() == (*it)->getId())
						{
							(*it) = CData::nowUser;
							break;
						}
					} 
				//д���ļ�
				CData::updataPatient(); 
				
				CTools::gotoxy(0,24);
				cout << "�޸ĳɹ�" << endl; 
				getch(); 
				//�༭�����
				this->oldPwdEdit->EditClear();
				this->newPwdEdit->EditClear();
				this->confirmNewPwdEdit->EditClear(); 
				
				return PATIENTWIN;
					
			}
			
		//���� 
		case 12:
			{	
				//�༭�����
				this->oldPwdEdit->EditClear();
				this->newPwdEdit->EditClear();
				this->confirmNewPwdEdit->EditClear(); 
				 
				return PATIENTCENTERWIN;
			}
			
	} 

	return PATIENTCHANGEPWDWIN;
}



void CPatientChangePwdWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShow->setContent("����: "+CTools::getCurrentTime()); 
	
	//��ʾ�����û����ֻ���
	this->phoneNumShow->setContent(CData::nowUser->getPhoneNum()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

	
}
