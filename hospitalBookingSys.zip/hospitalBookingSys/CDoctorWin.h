#ifndef _CDOCTORWIN_H_
#define _CDOCTORWIN_H_

#include "windowBase.h"
#include "ctrlBase.h"
#include "CData.h"


class CDoctorWin: public WinBase 
{
	public:
		
	CDoctorWin();
	CDoctorWin(int x, int y, int w, int h);
	~CDoctorWin();
	
	void showWin(); 
	int doAction();
		
	private:
	CLabel* title;
	CLabel* noticeLabel;
	CLabel* timeShowLabel;
	
	CButton* personalInfoBtn;
	CButton* medicalConsultationBtn;
	CButton* quitBtn;
 
		
	

	
}; 





#endif
