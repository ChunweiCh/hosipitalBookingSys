#include "CSimpleNotice.h"






CSimpleNotice::CSimpleNotice(int x, int y, int w, int h,string noticeShow)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(45,10,0,0,"��ʾ:",LABEL);
	
	this->noticeLabel = new CLabel(49,12,0,0,noticeShow,LABEL);
	

	this->returnBtn = new CButton(73,17,12,3,"ȷ��",BUTTON);
	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);

	this->addCtrl(returnBtn);

}

CSimpleNotice::~CSimpleNotice()
{
	
}

int CSimpleNotice::doAction()
{
	switch(this->ctrlIndex)
	{
		case 1:
			return 1;
		
	}
}

void CSimpleNotice::showWin()
{
	
	

	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		
}











