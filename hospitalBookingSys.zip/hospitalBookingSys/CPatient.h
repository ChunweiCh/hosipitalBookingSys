#ifndef _CPATIENT_H_
#define _CPATIENT_H_


#include "CUser.h"

class CPatient:public CUser
{
	public:
	CPatient();
	CPatient(int id, string userName, string pwd,Role role,string phoneNum,string identification);
	~CPatient();
	//�������
	CPatient(CPatient& other); 
	//��ȡ
	string getPhoneNum(); 
	string getIdentification();
	//���� 
	void setPhoneNum(string phoneNum);
	void setIdentification(string identification);
	private:
	string phoneNum;
	string identification;
	
	
	protected:
	 
		
};


#endif
