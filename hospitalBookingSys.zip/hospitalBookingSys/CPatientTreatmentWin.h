#ifndef _CPATIENTTREATMENTWIN_H_
#define _CPATIENTTREATMENTWIN_H_




#include "windowBase.h"
#include "ctrlBase.h"

#include "CData.h"
#include "CTable.h" 

//�û�ԤԼ��������--������Ϣ���� 
class CPatientTreatmentWin : public WinBase
{
	public:
	CPatientTreatmentWin();
	CPatientTreatmentWin(int x, int y, int w, int h);
	~CPatientTreatmentWin();
	
	int doAction();
	
	void showWin();
	void winRun();
		
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ������ͨ�û� 
	CLabel* timeShowLabel;//���ڵ�ʱ��
	CLabel* enterUserIdNoticeLabel;
	CLabel* upDownPageNoticeLabel;
	
	CEdit* frontDateEdit;
	CLabel* orLabel;
	CEdit* endDateEdit; 
	
	CEdit* enterUserIdEdit;
	
	CButton* searchBtn;
	//��ѯ����
	list<CAppointment*>findAppointmentMember;
	
	//��ͷ
	vector<string>tableHead;
	CTable* treatmentTable; 
	
	
	CButton* row1Btn; 
	CButton* row2Btn; 
	CButton* row3Btn; 
	CButton* returnBtn;
	
	
	
	
			
		
};



#endif
