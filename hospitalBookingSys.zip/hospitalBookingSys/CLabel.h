#ifndef _CLABEL_H
#define _CLABEL_H

#include <iostream>
#include <cstring>
#include "CTools.h"

#include "ctrlBase.h"

//�̳��﷨ class ������ 

using namespace std;

class CLabel: public CtrlBase
{

	
		
	public:

	CLabel(int x, int y,int width,int height,string content,CONTROL ctrlType);
	~CLabel();
	void show(); 
		
};




























#endif
