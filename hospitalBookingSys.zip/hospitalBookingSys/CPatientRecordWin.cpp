#include "CPatientRecordWin.h"




CPatientRecordWin::CPatientRecordWin(int x, int y, int w , int h)
:WinBase(x,y,w,h)
{	
	this->editFlag = editFlag;
	
	this->title = new CLabel(16,1,0,0,"�����¼����",LABEL);	
	this->noticeLabel = new CLabel(3,4,0,0,"",LABEL);
	this->timeShowLabel = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->patientIdLabel =  new CLabel(8,7,0,0,"�û�ID: ",LABEL);
	this->patientIdShow =  new CLabel(23,7,0,0,"",LABEL);
	this->appointmentPatientDesLabel = new CLabel(8,10,0,0,"ԤԼ����",LABEL);
	this->doctorDescriptionLabel = new CLabel(8,13,0,0,"��������",LABEL);

	this->appointmentPatientDesEdit = new CLabel(23,10,20,3,"",LABEL);
	this->doctorDescriptionEdit = new CLabel(23,13,20,4,"",LABEL);
	 
	
	this->returnBtn = new CButton(15,18,10,3,"����",BUTTON);
	
	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	
	this->addCtrl(patientIdLabel);
	this->addCtrl(patientIdShow);
	this->addCtrl(appointmentPatientDesLabel);
	this->addCtrl(doctorDescriptionLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(appointmentPatientDesEdit);
	this->addCtrl(doctorDescriptionEdit);
	
	this->addCtrl(returnBtn);//10

	
	
}

CPatientRecordWin::~CPatientRecordWin()
{
 
}


int CPatientRecordWin::doAction() 
{	
	
	switch(this->ctrlIndex)
	{
		
		
			
		//����
		case 10 :
			{	
			
				this->editFlag = false;
				//�༭����� 
				this->appointmentPatientDesEdit->EditClear();
				this->doctorDescriptionEdit->EditClear();
				return TREATMENTWIN;	
				
			}
			
	}
	return TREATMENTWIN;
} 


void CPatientRecordWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	
	this->patientIdShow->setContent(CData::selectedAppointment->getPatientPhoneNum());
	if(this->editFlag == false)
	{
		
		
		//��ʾ ҽ������
		this->appointmentPatientDesEdit->setContent(CData::selectedAppointment->getSelfDescription());
		this->doctorDescriptionEdit->setContent(CData::selectedAppointment->getDoctorDescription());
		
	}
	
	
	
	
	
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		
	
	
}

















