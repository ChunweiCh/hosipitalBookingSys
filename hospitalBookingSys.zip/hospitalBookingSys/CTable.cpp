#include "CTable.h"


CTable::CTable(int x, int y, int w, int h,string content,CONTROL ctrlType,vector<string>tableHead)
:CtrlBase(x,y,w, h,content,ctrlType)
{
	this->tableHead = tableHead;
	
	this->pageAll = 0;
	this->pageCount = pageCount;
	this->pageIndex = 1;//��ǰҳ 
	this->allRow; //Ҫ��ʾ��������
	this->row = row; //ÿһҳ������ 
	 
}




CTable::~CTable()
{
	
}


int CTable::getPageIndex()
{
	return this->pageIndex;
}
void CTable::show()
{	
	
	int table_col_w =0;
	int table_x_change=0;
	int count=0;
	
	for (int i=0; i<this->tableHead.size();i++)
	{	
	    
		table_col_w = tableHead[i].size() + 3;
		
		CTools::printTable((this->x + table_x_change),this->y,table_col_w,1,4,1);
		
		CTools::gotoxy(this->x+ table_x_change+2,this->y+1);
		cout << this->tableHead[i];
		table_x_change += table_col_w;
		
	}
	
	
	
	
	
}

void CTable::setPageIndex(int num)
{
	this->pageIndex = num;
}

//��ʾҽ������ 
void CTable::showDoctorData(list<CDoctor*>&doctorList)
{	
	
	
	int lineLimit =0;
	int count =0;
	string doctorIdStart = "D";
	size_t colCount = this->tableHead.size();
	list<CDoctor*>::iterator it = doctorList.begin();
	
	advance(it,(this->pageIndex-1)*3); 
	for(; it != doctorList.end() &&count<3 ; ++it,++count)
	{	
		lineLimit++;
		int table_x_change=0;
		//������ͷ��ȡ�п�
		for(int i=0; i< colCount;i++)
		{	
			int  table_col_w = this->tableHead[i].size()+3;
			CTools::gotoxy(this->x+ table_x_change+2,this->y+2*lineLimit+1);
			
			switch(i)
			{
				case 0: //ҽ��ID
					cout <<  doctorIdStart + CTools::intToString((*it)->getId());
					break;
				case 1://ҽ������
					cout <<  (*it)->getUserName();
					break;
				case 2: //ҽ��ְλ
					cout << (*it)->getDocPostionString(); 
					break;
				case 3: //����
					cout << (*it)->getDepartment(); 
					break; 
				case 4://����ҽԺ
					cout << (*it)->getHospitalName();
					break; 
				case 5: //������Ϣ 
					cout << (*it)->getDescriptionInfo(); 
					break; 
				default:
					break;	
					
				
			}
			table_x_change += table_col_w;
			
		} 
		
			
		
	}
	 
	
	
}

//��ʾ�û�����
void CTable::showPatientData(list<CPatient*>&patientList)
{
	int lineLimit =0;
	int count =0;
	
	if(this->tableHead.empty()) return;
	size_t colCount = this->tableHead.size();
	//��ʼ�������� 
	list<CPatient*>::iterator it = patientList.begin();
	//ƫ���������㷭ҳ��ʾ���� 
	

	
	advance(it,(this->pageIndex-1)*3); 
	
	for(; it != patientList.end() &&count<3 ; ++it,++count)
	{	
		if(*it==NULL)continue; 
		lineLimit++;
		int table_x_change=0;
		//������ͷ��ȡ�п�
		for(int i=0; i< colCount;i++)
		{	
			//���ȵİ�ȫ�ж� 
			int  table_col_w = (i< this->tableHead.size())?this->tableHead[i].size()+3 : 10;
			CTools::gotoxy(this->x+ table_x_change+2,this->y+2*lineLimit+1);
			
			switch(i)
			{
				case 0: //�˺�
				{
					if(*it)
					{
						cout <<  (*it)->getPhoneNum();
					}
					else
					{
						cout<<"";
					 } 
					break;
				}
					
				case 1://������Ϣ
				{
					if(*it)
					{
						string id = (*it)->getIdentification();
						cout << (id.empty()?"�û���������Ϣ":id);
					}
					else
					{
						cout<<"";
					 } 
					break;
				}
					
				default:
					break;	
					
				
			}
			table_x_change += table_col_w;
			
		} 
		
			
		
	}	
	
	
	
}

//��ʾ����
void CTable::showDepartmentData(vector<CDepartment*>&deparmentVec)
{
	int lineLimit =0;
	int count =0;
	
	if(this->tableHead.empty()) return;
	size_t colCount = this->tableHead.size();
	//��ʼ�������� 
	vector<CDepartment*>::iterator it = deparmentVec.begin();
	//ƫ���������㷭ҳ��ʾ���� 
	

	
	advance(it,(this->pageIndex-1)*3); 
	
	for(; it != deparmentVec.end() &&count<3 ; ++it,++count)
	{	
		if(*it==NULL)continue; 
		lineLimit++;
		int table_x_change=0;
		//������ͷ��ȡ�п�
		for(int i=0; i< colCount;i++)
		{	
			//���ȵİ�ȫ�ж� 
			int  table_col_w = (i< this->tableHead.size())?this->tableHead[i].size()+3 : 10;
			CTools::gotoxy(this->x+ table_x_change+2,this->y+2*lineLimit+1);
			
			switch(i)
			{
				case 0: //����ID 
				{
					if(*it)
					{
						cout <<  (*it)->getDepartmentId();
					}
					else
					{
						cout<<"";
					 } 
					break;
				}
					
				case 1://�������� 
				{
					if(*it)
					{
						cout <<  (*it)->getDepartmentName();
						
					}
					else
					{
						cout<<"";
					 } 
					break;
				}
				case 2://����˵�� 
				{
					if(*it)
					{
						cout <<  (*it)->getDepartmentInfo();
						
					}
					else
					{
						cout<<"";
					} 
					break;
				}	
					
				default:
					break;	
					
				
			}
			table_x_change += table_col_w;
			
		} 
		
			
		
	}	
	
}

//��ʾԤԼ��
void CTable::showAppointmentData(list<CAppointment*>&appointmentList)
{	
	
    
	//������б�
	if(appointmentList.empty()) return;
	
	int skip = (this->pageIndex - 1)*3;
	//����Խ�� 
	if(skip >= appointmentList.size()) return;
	size_t colCount = this->tableHead.size();	
	int lineLimit =0;
	int count =0;
	//Ĭ��ҽԺ�� ����ҽԺ 
	string hospitalName = "����ҽԺ"; 
	
	list<CAppointment*>::iterator rit = appointmentList.begin();
	
	advance(rit,skip); 
	//����ʵ�� 
	for(; rit != appointmentList.end() &&count<3 ; ++rit,++count)
	{	
		if(*rit==NULL)continue; 
		lineLimit++;
		int table_x_change=0;
		//������ͷ��ȡ�п�
		for(int i=0; i< colCount;i++)
		{	
			int  table_col_w = this->tableHead[i].size()+3;
			CTools::gotoxy(this->x+ table_x_change+2,this->y+2*lineLimit+1);
			
			switch(i)
			{
				case 0: //ԤԼ��� 
					if(*rit)
					{
						cout <<  (*rit)->getAppointmentId();
					}
					else
					{
						cout << "";
					}
					break;
				case 1://ԤԼʱ�� 
					
					if(*rit)
					{
						cout <<  (*rit)->getAppointmentTime();
					}
					else
					{
						cout << "";
					}
					break;
				case 2: //ԤԼ����ʱ�� 
					
					if(*rit)
					{
						cout << (*rit)->getAppointmentTurns();
					}
					else
					{
						cout << "";
					}
					break;
				case 3: //ԤԼҽԺ
					
					if(*rit)
					{
						cout <<  hospitalName;
					}
					else
					{
						cout << "";
					}
					break; 
				case 4:// ԤԼ����
					
					if(*rit)
					{
						cout <<(*rit)->getDepartment(); 
					}
					else
					{
						cout << "";
					}
					break; 
				case 5://ԤԼҽ������ 
					
					if(*rit)
					{
						cout << (*rit)->getDoctorName();
					}
					else
					{
						cout << "";
					}
					break;  
				case 6: //ԤԼ״̬ 
					
					if(*rit)
					{
						cout << (*rit)->getAppointmentStatusString();
					}
					else
					{
						cout << "";
					}
					break; 
				default:
					break;	
					
				
			}
			table_x_change += table_col_w;
			
		} 
		
			
		
	}
	 
	
}

void  CTable::showTreatmentData(list<CAppointment*>&appointmentList)
{
		//������б�
	if(appointmentList.empty()) return;
	
	int skip = (this->pageIndex - 1)*3;
	//����Խ�� 
	if(skip >= appointmentList.size()) return;
	size_t colCount = this->tableHead.size();	
	int lineLimit =0;
	int count =0;
	//Ĭ��ҽԺ�� ����ҽԺ 
	string hospitalName = "����ҽԺ"; 
	//���� 
	list<CAppointment*>::iterator it = appointmentList.begin();
	
	advance(it,skip); 
	for(; it != appointmentList.end() &&count<3 ; ++it,++count)
	{	
		if((*it)==NULL)continue;
		
		int status = (*it)->getAppointmentStatusInt();
		if(status !=2 && status!=4)continue;
		
		
		lineLimit++;
		int table_x_change=0;
		//�ҵ��ȴ������ԤԼ������ʾ
		
			//������ͷ��ȡ�п�
		
			for(int i=0; i< colCount;i++)
			{	
				int  table_col_w = this->tableHead[i].size()+3;
				CTools::gotoxy(this->x+ table_x_change+2,this->y+2*lineLimit+1);
				
				switch(i)
				{
					case 0: //ԤԼ��� 
						if(*it)
						{
							cout <<  (*it)->getAppointmentId();
						}
						else
						{
							cout << "";
						}
						break;
					case 1://����ʱ�� 
						
						if(*it)
						{
							cout <<  (*it)->getAppointmentTime() + (*it)->getAppointmentTurns();
						}
						else
						{
							cout << "";
						}
						break;
					case 2: //����ҽԺ
						
						if(*it)
						{
							cout <<  hospitalName;
						}
						else
						{
							cout << "";
						}
						break;
					case 3: // ԤԼ����
						
						if(*it)
						{
						cout <<(*it)->getDepartment(); 
						}
						else
						{
							cout << "";
						}
						break; 
					case 4://ҽ�� ���� 
						
						if(*it)
						{
							cout << (*it)->getDoctorName();
						}
						else
						{
							cout << "";
						}
						break; 
					case 5: //ԤԼ״̬ 
						
						if(*it)
						{
							cout << (*it)->getAppointmentStatusString();
						}
						else
						{
							cout << "";
						}
						break;  
				
					default:
						break;	
						
					
				}
				table_x_change += table_col_w;
				
			} 
		
		
		
		
			
		
	}
}

void CTable::showDocTreatmentData(list<CAppointment*>&appointmentList)
{
	
		//������б�
	if(appointmentList.empty()) return;
	
	int skip = (this->pageIndex - 1)*3;
	//����Խ�� 
	if(skip >= appointmentList.size()) return;
	size_t colCount = this->tableHead.size();	
	int lineLimit =0;
	int count =0;
	//Ĭ��ҽԺ�� ����ҽԺ 
	
	list<CAppointment*>::iterator it = appointmentList.begin();
	
	advance(it,skip); 
	for(; it != appointmentList.end() &&count<3 ; ++it,++count)
	{	
		if((*it)==NULL||(*it)->getAppointmentStatusInt() != 2)
		{
			continue; 	
		}
		lineLimit++;
		int table_x_change=0;
		//�ҵ��ȴ������ԤԼ������ʾ
		
			//������ͷ��ȡ�п�
		
			for(int i=0; i< colCount;i++)
			{	
				int  table_col_w = this->tableHead[i].size()+3;
				CTools::gotoxy(this->x+ table_x_change+2,this->y+2*lineLimit+1);
				
				switch(i)
				{
					case 0: //ԤԼ��� 
						if(*it)
						{
							cout <<  (*it)->getAppointmentId();
						}
						else
						{
							cout << "";
						}
						break;
					case 1://�����û�ID 
						
						if(*it)
						{
							cout <<  (*it)->getPatientPhoneNum();
						}
						else
						{
							cout << "";
						}
						break;
					
					case 2: //ԤԼ״̬ 
						
						if(*it)
						{
							cout << (*it)->getAppointmentStatusString();
						}
						else
						{
							cout << "";
						}
						break;  
				
					default:
						break;	
						
					
				}
				table_x_change += table_col_w;
				
			} 
		
		
		
		
			
		
	}
	
	
	
}

//��ʾҳ�� 
void CTable::showPage(int row,int allRow)
{
	this->pageAll = allRow/row;
	this->pageAll += allRow%row ==0?0:1;
	
	CTools::gotoxy(this->x+20,this->y+9);
	cout <<this->pageIndex << "/" << this->pageAll << endl;
	 
}



void CTable::showNextPage()
{	
	if(this->pageIndex >= this->pageAll)
	{
		CTools::gotoxy(this->x+15,this->y+11);
//		cout << "��ǰ�������һҳ";
	}
	else 
	{
		this->pageIndex++;
	}
	
}

void CTable::showLastPage()
{
	if(this->pageIndex <= 1)
	{
		CTools::gotoxy(this->x+15,this->y+11);
//		cout << "��ǰ�Ѿ��ǵ�һҳ��";
	}
	else 
	{
		this->pageIndex--;
	}
	
	
}


//��ȡҽ����ǰҳ 
list<CDoctor*> CTable::getCurrentPageDoctors(list<CDoctor*>& doctorList)
{
	list<CDoctor*> pageDoctors;
    int skip = (pageIndex - 1) * 3;  // ÿҳ3��
    list<CDoctor*>::iterator it = doctorList.begin();
    advance(it, skip);
    
    for (int i = 0; i < 3 && it != doctorList.end(); ++i, ++it) {
        if (*it != NULL) {
            pageDoctors.push_back(*it);
        }
    }
    return pageDoctors;
}


list<CAppointment*> CTable::getCurrentPageAppointment(list<CAppointment*>& appointmentList)
{
    list<CAppointment*> pageAppointments;
    int skip = (pageIndex - 1) * 3;  // ÿҳ3��
    list<CAppointment*>::iterator it = appointmentList.begin();
    advance(it, skip);
    
    for (int i = 0; i < 3 && it != appointmentList.end(); ++i, ++it) {
        if (*it != NULL) {
            pageAppointments.push_back(*it);
        }
    }
    return pageAppointments;
}








