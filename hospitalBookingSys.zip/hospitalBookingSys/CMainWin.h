#ifndef _CMAINWIN_H_
#define _CMAINWIN_H_

#include "windowBase.h"


class CMainWin : public WinBase
{
	public:
		CMainWin();
		CMainWin(int x, int y, int w, int h);
		~CMainWin(); 
		
		int doAction();
	private:
	CLabel* title;
	CLabel* myStudentNumLabel;
	CButton* loginWinBtn;
	CButton* registWinBtn;
	CButton* quitBtn;
	
	
		
	protected:	
		
}; 



#endif
