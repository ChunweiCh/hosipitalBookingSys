#ifndef _CPATIENTWIN_H_
#define _CPATIENTWIN_H_

#include "windowBase.h"
#include "ctrlBase.h"

#include "CData.h"

class CPatientWin : public WinBase
{	
	public:
		CPatientWin();
		CPatientWin(int x, int y, int w, int h);
		~CPatientWin(); 
		void showWin();
		int doAction();
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShow;//���ڵ�ʱ��
	
	CButton* personalCenBtn;
	CButton* bookingManageBtn;
	CButton* startBookingBtn;
	CButton* medicalConsultationBtn;
	CButton* quitBtn;
	

		
		
		
		
		
	
};




#endif
