#include "CDepartment.h"




CDepartment::CDepartment(int departmentId, string departmentName, string departmentInfo)
{
	this->departmentId = departmentId;
	this->departmentName = departmentName;
	this->departmentInfo =  departmentInfo;
	
}

CDepartment::~CDepartment()
{
	
}

//��ȡ
string CDepartment::getDepartmentId()
{
	return CTools::intToString(this->departmentId);	
}

string CDepartment::getDepartmentName()
{
	return this->departmentName;
}
string CDepartment::getDepartmentInfo()
{
	return this->departmentInfo;
}

//���� 
void CDepartment::setDepartmentName(string departmentName)
{
	this->departmentName = departmentName;	
}

void CDepartment::setDepartmentInfo(string departmentInfo)
{
	this->departmentInfo = departmentInfo;
}
