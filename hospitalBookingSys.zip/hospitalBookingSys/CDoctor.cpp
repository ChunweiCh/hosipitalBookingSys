#include "CDoctor.h"



CDoctor::CDoctor()
{
	
}

CDoctor::CDoctor(int id,string userName, string pwd,Role role,string department,string descriptionInfo, DocPosition docPosition,string hospitalName)
:CUser(id,userName,pwd,role)
{
	this->department = department;
	this->descriptionInfo = descriptionInfo;
	this->docPosition = docPosition;
	this->hospitalName = "����ҽԺ"; 
		
} 

CDoctor::~CDoctor()
{
	
} 
//�������캯��
CDoctor::CDoctor(CDoctor& other)
:CUser(other)
{
	this->department = other.department;
	this->descriptionInfo = other.descriptionInfo;
	this->docPosition = other.docPosition; 
	this->hospitalName = other.hospitalName; 
} 

//��ȡ
string CDoctor::getDepartment()
{
	return this->department;
} 

string CDoctor::getDescriptionInfo()
{
	return this->descriptionInfo;
}

int CDoctor::getDocPostion_enum()
{
	return this->docPosition;
}

string CDoctor::getHospitalName()
{
	return this->hospitalName;
}
string CDoctor::getDocPostionString()
{
	switch(this->docPosition)
	{
		case 1 : 
			return "������";
		case 2:
			return "����";
		case 3:
			return "���";
		case 4:
			return "�ڿ�"; 
	}
	
}
//����
void CDoctor::setDepartment(string department)
{
	this->department = department;
} 

void CDoctor::setDescriptionInfo(string descriptionInfo)
{
	this->descriptionInfo = descriptionInfo;
}

void CDoctor::setDocPosition_enum(DocPosition docPosition)
{
	this->docPosition = docPosition;
}


