#include "CMainWin.h"




CMainWin::CMainWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(13,1,0,0,"����ԤԼ����ϵͳ",LABEL);
	this->myStudentNumLabel = new CLabel(22,13,0,0,"ѧ��:OMO250430",LABEL);
	
	this->loginWinBtn = new CButton(15,4,10,3,"��¼",BUTTON);
	this->registWinBtn = new CButton(15,7,10,3,"ע��",BUTTON); 
	this->quitBtn = new CButton(15,10,10,3,"�˳�",BUTTON);
	
	this->addCtrl(title);
	this->addCtrl(myStudentNumLabel);
	this->addCtrl(loginWinBtn);
	this->addCtrl(registWinBtn);
	this->addCtrl(quitBtn);
	
}

CMainWin::~CMainWin()
{
	
}

int CMainWin::doAction()
{
	switch(this->ctrlIndex)
	{
		case 2:return LOGINWIN; 
		case 3: return REGISTWIN;
			
		case 4: exit(0);
	}

	
}








































