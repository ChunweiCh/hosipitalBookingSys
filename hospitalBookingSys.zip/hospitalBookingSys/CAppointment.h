#ifndef _CAPPOINTMENT_H_
#define _CAPPOINTMENT_H_



#include <string>
#include <list>
#include "CDoctor.h"
using namespace std;

typedef enum
{ //1--��ȡ�� 2--������ 3--ȡ��ԤԼ 4--�Ѿ��� 5-���� 
	PENDINGAPPOINTMENT = 1,
	PENDINGTREATMENT,
	CANCELLED,
	COMPLETE,
	DELATE, 
	
	
}AppointmentStatus;



class CAppointment 
{
	public:
	CAppointment();
	CAppointment(int appointmentId,string patientPhoneNum, string orderTime, string department, string doctorName
				,string appointmentTime, string appointmentTurns ,string selfDescription, string doctorDescription, AppointmentStatus status);
	~CAppointment();
	
	//��ȡ
	int getAppointmentId();
	string getPatientPhoneNum();
	string getOrderTime();
	string getDepartment();
	string getDoctorName();
	string getAppointmentTime();
	string getAppointmentTurns();
	string getSelfDescription();
	string getDoctorDescription();
	string getAppointmentStatusString();
	int getAppointmentStatusInt();
	
	//���� 
	void setPatientPhoneNum(string patientPhoneNum);
	void setOrderTime(string orderTime);
	void setDepartment(string department);
	void setDoctorName(string doctorName);
	void setAppointmentTime(string appointmentTime);
	void setAppointmentTurns(string appintmentTurns);
	void setSelfDescription(string selfDescription);
	void setDoctorDescription(string doctorDescription);
	
	int setAppointmentStatusInt(AppointmentStatus status);
	
	private:
	int appointmentId;
	string patientPhoneNum;
	string orderTime;
	string department;
	string doctorName;
	string appointmentTime;
	string appointmentTurns;
	string selfDescription;
	string doctorDescription;
	AppointmentStatus status;
	
		
	
		
};





































#endif
