#include "CPatientManageAppointmentWin.h"




CPatientManageAppointmentWin::CPatientManageAppointmentWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(16,1,0,0,"ԤԼ��������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ,��ͨ�û�",LABEL);
	this->timeShow = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->startAppointmentBtn =new CButton(8,8,20,3,"ԤԼ����",BUTTON);
	this->bookingVaccineBtn = new CButton(32,8,20,3,"ԤԼ����",BUTTON);
	this->getVaccineListBtn = new CButton(8,11,20,3,"��������б�",BUTTON);
	this->returnBtn = new CButton(32,11,20,3,"  	����	 ",BUTTON);
	
	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShow);
	this->addCtrl(startAppointmentBtn); //3
	this->addCtrl(bookingVaccineBtn);//4
	this->addCtrl(getVaccineListBtn);//5
	this->addCtrl(returnBtn);//6
	
}


CPatientManageAppointmentWin::~CPatientManageAppointmentWin()
{
	
}




CPatientManageAppointmentWin::doAction()
{
	switch(this->ctrlIndex)
	{
		//ԤԼ���� 
		case 3:
			return PATIENTSTARTBOOKINGWIN;
		//ԤԼ���� 
		case 4:
			return PATIENTWIN;
		//��������б� 
		case 5:
			return PATIENTWIN;
		//���� 
		case 6:
			return PATIENTWIN;
		
		

	} 
	return PATIENTWIN;
}



void CPatientManageAppointmentWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShow->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

	
}





