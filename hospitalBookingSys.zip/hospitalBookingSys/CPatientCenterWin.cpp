#include "CPatientCenterWin.h"



CPatientCenterWin::CPatientCenterWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(16,1,0,0,"�û�������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ,��ͨ�û�",LABEL);
	this->timeShow = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->userInfoBtn = new CButton(10,7,12,3,"��Ϣ����",BUTTON);
	this->changePwdBtn = new CButton(25,7,12,3,"�޸�����",BUTTON);
	this->returnBtn = new CButton(10,10,12,3,"����",BUTTON);	

		
	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShow);
	this->addCtrl(userInfoBtn);
	this->addCtrl(changePwdBtn);
	this->addCtrl(returnBtn);



}


CPatientCenterWin::~CPatientCenterWin()
{
	
}




CPatientCenterWin::doAction()
{
	switch(this->ctrlIndex)
	{
		//��Ϣ���� 
		case 3:
			return UPDATEPATIENTINFOWIN;
		//�޸����� 
		case 4:
			return PATIENTCHANGEPWDWIN;
		//����	
		case 5:
			return PATIENTWIN;
	

	} 
}



void CPatientCenterWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShow->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

	
}

