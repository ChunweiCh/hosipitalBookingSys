#include "CLabel.h"




CLabel::CLabel(int x, int y,int width,int height,string content,CONTROL ctrlType)
:CtrlBase(x,y,width,height,content,ctrlType)
{


}
CLabel::~CLabel()
{
	
}

//�ڸǸ���show 
void CLabel::show()
{	

	CTools::paintWindow(this->x,this->y,this->width,this->height); 
	

	CTools::gotoxy(this->x+2,this->y+1);
	cout<< this->content;

	

}





