#ifndef _CDOCTORMEDICALCONSULTATIONWIN_H_
#define _CDOCTORMEDICALCONSULTATIONWIN_H_


#include "windowBase.h"
#include "ctrlBase.h"

#include "CTable.h"
#include "CData.h"

//ҽ�������� --������Ϣ 
class CDoctorMedicalConsultationWin : public WinBase
{
	public:
	CDoctorMedicalConsultationWin();
	CDoctorMedicalConsultationWin(int x, int y, int w, int h);
	~CDoctorMedicalConsultationWin();
	
	int doAction();
	
	void showWin();
	void winRun(); 
	 
		
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShowLabel;//���ڵ�ʱ��
	CLabel* upDownPageNoticeLabel;
	

	
	vector<CAppointment*>findAppointmentMember;
	
	//��ͷ
	vector<string>tableHead;
	CTable* treatmentTable; 
	
	
	CButton* row1Btn; 
	CButton* row2Btn; 
	CButton* row3Btn; 
	CButton* returnBtn;
	
	
	
	
			
		
};



#endif
