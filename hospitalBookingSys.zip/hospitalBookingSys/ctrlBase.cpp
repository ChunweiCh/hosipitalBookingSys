#include "ctrlBase.h"




CtrlBase::CtrlBase(int x, int y, int width, int height, string content,CONTROL ctrlType)
{
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	
	this->content = content;
	
	this->ctrlType = ctrlType;
	
}

CtrlBase::~CtrlBase()
{
	
}

int CtrlBase::getX()
{
	return x;
}

int CtrlBase::getY()
{
	return y;
}

int CtrlBase::getCtrlType()
{
	return ctrlType;
}
string CtrlBase::getContent()
{
	return content;
}

void CtrlBase::setContent(string  content)
{
	this->content = content;
 } 


 void CtrlBase::show()
{
	
}

void CtrlBase::editKeyListen(char ch)
{
	
} 

void CtrlBase::EditClear()
{
	
	
 } 
