#include "CRoleSelectWin.h"




CRoleSelectWin::CRoleSelectWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{	
	this->title = new CLabel(0,0,0,0,"",LABEL);
	this->adminRoleBtn = new CButton(15,14,0,0,"����Ա",BUTTON);
	this->doctorRoleBtn = new CButton(15,17,0,0,"ҽ��",BUTTON);
	this->patientRoleBtn = new CButton(15,20,0,0,"��ͨ�û�",BUTTON);
	
	this->addCtrl(title);
	this->addCtrl(adminRoleBtn);//1
	this->addCtrl(doctorRoleBtn);//2
	this->addCtrl(patientRoleBtn);//3
	
}

CRoleSelectWin::~CRoleSelectWin()
{
	
} 

int CRoleSelectWin::doAction()
{
	switch(this->ctrlIndex)
	{
		case 1:
			return 1;
		case 2:
			return 2;
		case 3:	
			return 3;
			 
	}
	
	
}





















