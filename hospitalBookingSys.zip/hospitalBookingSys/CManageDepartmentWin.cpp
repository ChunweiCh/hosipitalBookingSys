#include "CManageDepartmentWin.h"



CManageDepartmentWin::CManageDepartmentWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	
	this->findDepartmentMember = findDepartmentMember;
	this->title = new CLabel(36,1,0,0,"���ҹ�������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ, admin, ����Ա",LABEL);
	this->timeShowLabel = new CLabel(58,4,0,0,"����: ",LABEL);
	this->enterUserIdNoticeLabel = new CLabel(5,7,0,0,"���������ID: ",LABEL);
	this->upDownPageNoticeLabel = new CLabel(57,19,0,0,"�� �� �� ��ҳ",LABEL);
	
	this->enterUserIdEdit = new CEdit(25,7,30,3,"",EDIT,10,1,0);
	
	this->searchBtn = new CButton(57,7,10,3,"��ѯ",BUTTON);
	//��ͷ
	this->tableHead = tableHead;
	tableHead.push_back("    ����ID    ");
	tableHead.push_back("    ��������    ");
	tableHead.push_back("   ����˵��   ");
	
	this->departmentTable = new CTable(10,10,0,0,"",TABLE,tableHead); 
	this->addDoctorBtn = new CButton(68,7,12,3,"��������",BUTTON);
	this->row1Btn = new CButton(5,12,0,0,"",BUTTONDYNAMIC);
	this->row2Btn = new CButton(5,14,0,0,"",BUTTONDYNAMIC);
	this->row3Btn = new CButton(5,16,0,0,"",BUTTONDYNAMIC);
	this->returnBtn = new CButton(10,19,10,3,"����",BUTTON); 
	
	this->addCtrl(title); 
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(enterUserIdNoticeLabel);
	this->addCtrl(upDownPageNoticeLabel);
	this->addCtrl(enterUserIdEdit);
	this->addCtrl(searchBtn); //6
	this->addCtrl(departmentTable);//7
	this->addCtrl(addDoctorBtn);//8
	this->addCtrl(row1Btn);//9
	this->addCtrl(row2Btn);//10
	this->addCtrl(row3Btn);//11
	this->addCtrl(returnBtn); //12
	
	
}




CManageDepartmentWin::~CManageDepartmentWin()
{
	
}
	
int CManageDepartmentWin::doAction()
{
	switch(this->ctrlIndex)
	{
		//��ѯ 
		case 6:
			{
				string findDepartmentId = this->enterUserIdEdit->getContent();
				//ÿ�����ض�Ҫ���findmember������
				
				this->findDepartmentMember.clear();
				vector<CDepartment*>::iterator it;
				for(it = CData::deparmentVec.begin(); it != CData::deparmentVec.end();++it)
				{
					string departmentId = (*it)->getDepartmentId();
					if(departmentId.find(findDepartmentId)!= string::npos)
					{
						findDepartmentMember.push_back(*it);
					}
					 
				}
				//��ѯ�ж�
				if(findDepartmentMember.empty())
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->departmentTable->setPageIndex(1);
					
					this->enterUserIdEdit->setContent("δ�ҵ��������");
					this->enterUserIdEdit->show();
					getch();
					this->enterUserIdEdit->setContent("");
					this->enterUserIdEdit->show();
					return MANAGEDEPARTMENTWIN;
				}
				else 
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->departmentTable->setPageIndex(1);
					return MANAGEDEPARTMENTWIN;
				}
				
			}
			
		//����	
		case 8:
			{	
				
				this->enterUserIdEdit->EditClear();
				this->findDepartmentMember.clear();
				this->departmentTable->setPageIndex(1);
			}
			return ADMINWIN;
		//��ҳ���ر����� 
		case -2:
			return MANAGEDEPARTMENTWIN; 
	}
	
	
}
	
void CManageDepartmentWin::showWin()
{
	

	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
	 
	if(this->findDepartmentMember.empty())
	{
		this->departmentTable->showDepartmentData(CData::deparmentVec);	
		this->departmentTable->showPage(3,CData::deparmentVec.size());
	}
	else
	{
		this->departmentTable->showDepartmentData(this->findDepartmentMember);	
		this->departmentTable->showPage(3,this->findDepartmentMember.size());
	}
	
		

}

void CManageDepartmentWin::winRun()
{
	int i=0, key= 0;
  
    
    // �ҵ���ʼ�۽��Ŀؼ�
    for (i=0; i<this->ctrlCount; i++)
    {
        if (this->ctrlArr[i]->getCtrlType() == EDIT)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                          this->ctrlArr[i]->getY()+1);
            break;
        }
        else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                 this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
            // Set arrow immediately for dynamic buttons
            if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
            {
                static_cast<CButton*>(this->ctrlArr[i])->setContent("��");
                this->ctrlArr[i]->show();
                
            }
            break;
        }
    }
    
    // ���浱ǰ�۽����а�ťָ��
    CButton* currentRowBtn = NULL;
    if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
    {
        currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
    }
    // ������������ 
    while (1)
    {
        key = CTools::getKey();
        switch(key)
        {
            case KEY_DOWN:
            {	
            	// �����ǰ�а�ť�ļ�ͷ
                if (currentRowBtn != NULL)
                {
                    currentRowBtn->setContent("");
                    currentRowBtn->show();
                    currentRowBtn = NULL;
                }
                
                i++;
                if (i == this->ctrlCount) i = 0;
                
                while(1)
                {
                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
                    {	
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                                      this->ctrlArr[i]->getY()+1);
                        break;
                    }
                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
                    {
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
                        // ������а�ť����ʾ��ͷ
                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
                        {
                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
                            currentRowBtn->setContent("��");
                            currentRowBtn->show();
                            showWin();
                        }
                        break;
                    }
                    i++;
                    if (i == this->ctrlCount) i = 0;
                }
                break;
			}
				    
                
                
            case KEY_UP:
                {	
                	// �����ǰ�а�ť�ļ�ͷ
	                if (currentRowBtn != NULL)
	                {
	                    currentRowBtn->setContent("");
	                    currentRowBtn->show();
	                    currentRowBtn = NULL;
	                }
                	i--;
	                if (i < 0) i = this->ctrlCount - 1;
	                
	                while(1)
	                {
	                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
	                                      this->ctrlArr[i]->getY()+1);
	                        break;
	                    }
	                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
	                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
	                         // ������а�ť����ʾ��ͷ
	                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
	                        {
	                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
	                            currentRowBtn->setContent("��");
	                            currentRowBtn->show();
	                            showWin();
	                        }
	                        
	                        break;
	                    }
	                    i--;
	                    if (i < 0) i = this->ctrlCount - 1;
	                }
	                break;
				}
                
                
                
            case KEY_RIGHT:
            	{
            		this->departmentTable->showNextPage();
	                this->ctrlIndex = -2;
	                return;
				}
                
                
            case KEY_LEFT:
                this->departmentTable->showLastPage();
                this->ctrlIndex = -2;
                return;
                
            case KEY_ENTER:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                    this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                {
	                    this->ctrlIndex = i;
	                    return;
	                }
	                break;
				}
                
                
            default:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                {    
	                    static_cast<CEdit*>(ctrlArr[i])->editKeyListen((char)key);
	                }
	                break;
				}
                
        }
    }
}





