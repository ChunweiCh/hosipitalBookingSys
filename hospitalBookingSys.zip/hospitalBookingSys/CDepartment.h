#ifndef _CDEPARTMENT_H_
#define _CDEPARTMENT_H_

#include <string>
#include "CTools.h"

using namespace std;
class CDepartment
{
	public:
	CDepartment();
	CDepartment(int departmentId, string departmentName, string departmentInfo);
	
	~CDepartment();
	
	//��ȡ
	string getDepartmentId();
	string getDepartmentName();
	string getDepartmentInfo();   
	
	//���� 
	void setDepartmentName(string departmentName);
	void setDepartmentInfo(string departmentInfo);
	
	
	private:
	int departmentId;
	string departmentName;
	string departmentInfo;
	
	
	
};




#endif
