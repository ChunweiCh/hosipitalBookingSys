#include "CDoctorCenterWin.h"







CDoctorCenterWin::CDoctorCenterWin(int x, int y, int w , int h)
:WinBase(x,y,w,h)
{	

	
	this->title = new CLabel(16,1,0,0,"ҽ��������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"",LABEL);
	this->timeShowLabel = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->changePwdBtn = new CButton(5,7,12,3,"�޸�����",BUTTON);
	
	this->returnBtn = new CButton(5,10,12,3,"����",BUTTON);	


	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(changePwdBtn);
	this->addCtrl(returnBtn);
	
	
}

CDoctorCenterWin::~CDoctorCenterWin()
{
 
}


int CDoctorCenterWin::doAction()
{	
	
	switch(this->ctrlIndex)
	{
		case 3:
			return DOCTORWIN;
			
		//����
		case 4:
			return DOCTORWIN; 
	}
	return DOCTORWIN;
} 


void CDoctorCenterWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	if(CData::nowDoctor != NULL)
	{
		welcomeNotice += CData::nowDoctor->getUserName();
	} 
	welcomeNotice += ", ҽ��";
	this->noticeLabel->setContent(welcomeNotice);
	
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

	
}

