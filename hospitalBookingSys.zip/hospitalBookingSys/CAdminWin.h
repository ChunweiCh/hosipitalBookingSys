#ifndef _CADMINWIN_H_
#define _CADMINWIN_H_

#include "windowBase.h"
#include "ctrlBase.h"

class CAdminWin : public WinBase 
{
	public:
	CAdminWin();
	CAdminWin(int x, int y, int w, int h);
	~CAdminWin();
	
	int doAction();
	void showWin();
	
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShow;//���ڵ�ʱ��
	
	CButton* userManageBtn;
	CButton* doctorBtn;
	CButton* departenmentManageBtn;
	CButton* dataStaticBtn;
	CButton* quitBtn;
	
	
	
	protected:	
		
		
};











#endif
