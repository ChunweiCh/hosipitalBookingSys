#ifndef _CPATIENTSTARTBOOKINGWIN_H_
#define _CPATIENTSTARTBOOKINGWIN_H_


#include <map>
#include "windowBase.h"
#include "ctrlBase.h"
#include "CComboBox.h"
#include "CData.h"
using namespace std;
class CPatientStartBookingWin : public WinBase
{	
	public:
		CPatientStartBookingWin();
		CPatientStartBookingWin(int x, int y, int w, int h);
		~CPatientStartBookingWin(); 
		void showWin();
		int doAction();
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShow;//���ڵ�ʱ��
	
	CLabel* selectHospitalLabel;
	CLabel* hospitalShow;
	
	CLabel* selectDepartmentLabel;
	CLabel* selectDoctorLabel;
	CLabel* selcetBookingTimeLabel;
	CLabel* patientInfoLabel;
	//������ 
	CLabel* departmentBoxShow;
	CLabel* doctorBoxShow;
	CLabel* ymdBoxShow;
	CLabel* dayTimeBookingBoxShow;
	
	CEdit* patientInfoEdit;

	CButton* departmentBoxBtn;
	CButton* doctorBoxBtn;
	CButton* ymdBoxBtn;
	CButton* bookingDayTimeBoxBtn;
	 
	CButton* confirmBtn;
	CButton* returnBtn;
	//������
	vector<string> departmentBoxVec;
	vector<string> doctorBox;
	vector<string> ymdBox;
	vector<string> dayTimeBox;

		
		
	
};



#endif
