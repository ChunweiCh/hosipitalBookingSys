#ifndef _CPATIENTCHANGEPWDWIN_H_
#define _CPATIENTCHANGEPWDWIN_H_




#include "windowBase.h"
#include "ctrlBase.h"

#include "CData.h"

class CPatientChangePwdWin : public WinBase
{	
	public:
		CPatientChangePwdWin();
		CPatientChangePwdWin(int x, int y, int w, int h);
		~CPatientChangePwdWin(); 
		void showWin();
		int doAction();
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShow;//���ڵ�ʱ��
	

	CLabel* phoneNumLabel;
	CLabel* phoneNumShow;
	CLabel* oldPwdLabel;
	CLabel* newPwdLabel;
	CLabel* confirmNewPwdLabel;
	
	CEdit* oldPwdEdit;
	CEdit* newPwdEdit;
	CEdit* confirmNewPwdEdit;
	
	CButton* confirmBtn;
	CButton* returnBtn;
	

		
		
	
};


#endif
