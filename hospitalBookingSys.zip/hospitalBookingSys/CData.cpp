#include "CData.h"

#include <fstream>
//��ʼ����̬��Ա
list<CUser*>CData::adminList;
//ҽ��
list<CDoctor*>CData::doctorList;
//����
list<CPatient*>CData::patientList; 
//ԤԼ��
list<CAppointment*>CData::appointmentList;
//������
vector<CDepartment*>CData::deparmentVec; 
//ʱ������
vector<string>CData::currentYmdVec;

//ÿ���ԤԼʱ��� 
vector<string>CData::dayTimeHmdVec;

//����Աѡ�е�ҽ������
CDoctor* CData::selectedDoctor; 
//����ѡ�е�ԤԼ����
CAppointment* CData::selectedAppointment;
//��¼��¼��ҽ����Ϣ
CDoctor* CData::nowDoctor;
bool CData::ownNowDoctor = false;
//��¼��¼����ͨ�û���Ϣ
CPatient* CData::nowUser; 
bool CData::ownNowUser = false;
//��¼��ǰ�û���ԤԼ��
list<CAppointment*>CData::nowUserAppointment; 
//��̬��ʾ��ǰʱ��δ�ȡ�ŵ��ж�����
int CData::currentPeopleInOneTime;
//�����ǰҽ��������
void CData::setCurrentDoctor(CDoctor* doctor,bool deepCopy)
{//���֮ǰӵ��nowDoctor������Ȩ���ͷ���
	if(ownNowDoctor&& nowDoctor)
	{
		delete nowDoctor;
		nowDoctor = NULL; 
	}
	if(deepCopy && doctor)
	{ //������� 
		nowDoctor = new CDoctor(*doctor);//ִ�п������� 
		ownNowDoctor = true;
	} 
	else 
	{//ʹ��ԭʼָ��
		nowDoctor = doctor;
		ownNowDoctor = false; 
		
	}
	
	
	
}  
 
void CData::setCurrentPatient(CPatient* patient,bool deepCopy)
{
	if(ownNowUser&& nowUser)
	{
		delete nowUser;
		nowUser = NULL;
	}
	if(deepCopy&&patient ) 
	{
		nowUser = new CPatient(*patient);
	}
	else 
	{
		nowUser = patient;
		ownNowUser = false;
	}
	
}
 
 
 
 
 
 
 
//�û����ݼ���
void CData::initAdmin()
{	
	
	//1.���ݼ��ص�һ�����г��� ��ʼ��һ���û��������ļ��ǿյ�д���û����� 
	fstream file("data/admin.txt",fstream::in | fstream::out | fstream::app);
	//�ж��ļ��Ƿ���Ա��� ������оͳ�ʼ������
	


	if(file.is_open())
	{
		//��λ���ļ�ĩβ�����ļ���С
		file.seekg(0,ios_base::end);
		int count = file.tellg();
		
		if(count <= 0)
		{	
			list<CUser*>::iterator it;
			CData::adminList.push_back(new CUser(1000,"admin","123456",ADMIN));
	
			for (it = CData::adminList.begin(); it != CData::adminList.end(); ++it)
			{
				file << (*it)->getId() << " " << (*it)->getUserName() << " " << (*it)->getPwd() << " " << (*it)->getRole() << endl;
			}
				
		} 
	 	else
		{//��Ϊ��ʱ ����λ����ͷ�� ���ж�ȡ���ݵ�������
			file.seekg(0,ios_base::beg);
			
			char buffer[128] = {0};
			int id = 0, role=0;
			char name[10] = {0}, pwd[10] = {0};
			while(file.peek() != EOF)// end of file == EOF
			{
				file.getline(buffer,30);
				//��ץ����
				sscanf(buffer,"%d %s %s %d",&id,name,pwd,&role);
				
				//�õ����ݷŵ�userlist��=== �Ѵ���������ݷŵ��ڴ���
				CData::adminList.push_back(new CUser(id,name,pwd,(Role)role)); 
				
				
			} 
			
			
		}
	} 
	else
	{
		cout << "open fail" << endl;
	}

	//�ر��ļ�
	file.close(); 
} 

//�����û�
void CData::addAdmin(CUser* pAdmin)
{	//���ļ� 
	fstream file("data/admin.txt", fstream::in| fstream::out| fstream::app);
	//��λ���ļ��ײ�
	file.seekg(0,ios_base::end);
	//д���ļ��ײ�
	file << pAdmin->getId() << " " << pAdmin->getUserName() << " " << pAdmin->getPwd() << " " << pAdmin->getRole() << endl;
	//�ļ�������ˢ��
	file.flush();
	//�ļ��ر�
	file.close(); 
		
} 

//�����û�����
void CData::updataAdmin() 
{
	//���ļ� ģʽѡ�� trunc
	fstream file("data/admin.txt", fstream::in| fstream::out| fstream::trunc);
	//list��������д���ļ� ��Ϊtruncģʽ������ļ�
	list<CUser*>::iterator it; //�������� 
	for (it = CData::adminList.begin(); it != CData::adminList.end(); ++it)
	{	//����д���ļ�
		file << (*it)->getId() << " " << (*it)->getUserName() << " " << (*it)->getPwd() << " " << (*it)->getRole() << endl;
		 		
	} 
	//�ļ�������ˢ��
	file.flush();
	//�ļ��ر�
	file.close(); 
	 
} 


//ҽ���û����ݼ���
void CData::initDoctor()
{	

	//���ļ� 
	
	fstream file("data/doctor.txt",fstream::in|fstream::out|fstream::app);
	
	//�ж��ļ��Ƿ��
	if(file.is_open())
	{
		//��λ���ļ�ĩβ�����ļ���С
		file.seekg(0,ios_base::end);
		int count = file.tellg();
		
		if(count <=0)
		{	//����ļ���Ϊ�ճ�ʼ������ 
			list<CDoctor*>::iterator it;
			CData::doctorList.push_back(new CDoctor(1001,"�ž���","123456",DOCTOR,"���ҽ��","����",SURGEON,"none"));
			CData::doctorList.push_back(new CDoctor(1002,"����","123456",DOCTOR,"�ڿ�ҽ��","����",INTERNIST,"none"));
			CData::doctorList.push_back(new CDoctor(1003,"����","123456",DOCTOR,"����ҽ��","����",ANESTHESIOLOGIST,"none"));
			for(it = CData::doctorList.begin(); it != CData::doctorList.end(); ++it)
			{
				file << (*it)->getId() << " " << (*it)->getUserName() << " " << (*it)->getPwd() << " " << (*it)->getRole() << " " << (*it)->getDepartment() 
				<< " " << (*it)->getDescriptionInfo() << " " << (*it)->getDocPostion_enum() << " " << (*it)->getHospitalName() << endl;
			} 
			
			
			
		}
		else
		{//��Ϊ��ʱ ��λ����ͷ
			file.seekg(0,ios_base::beg);
			char buffer[256] = {0};
			int id = 0, role = 0;
			char name[10]={0},pwd[10] ={0};
			char department[30]= {0};
			char description[50] = {0};
			int doctorPostion =0;
			char hospitalName[10] ={0};
			
			while(file.peek() != EOF)
			{
				file.getline(buffer,128);
				//��ץ����
				sscanf(buffer,"%d %s %s %d %s %s %d %s",&id,name,pwd,&role,department,description,&doctorPostion,hospitalName);
				
				CData::doctorList.push_back(new CDoctor(id,name,pwd,(Role)role,department,description,(DocPosition)doctorPostion,hospitalName)); 
				 
			}
			
			 
			
			
		}	
	} 
	else
	{
		cout << "Open file failed" << endl;
	}
	//�ر��ļ�
	file.close(); 
	
} 


//����ҽ��
void CData::addDoctor(CDoctor* pDoctor)
{
	//���ļ�
	fstream file("data/doctor.txt",fstream::in | fstream::out | fstream::app);
	
	//��λ���ļ��ײ�
	file.seekg(0,ios_base::end);
	
	//д���ļ��ײ�
	file << pDoctor->getId() << " " << pDoctor->getUserName() << " " << pDoctor->getPwd() << " " << pDoctor->getRole() << " " << pDoctor->getDepartment() 
	<< " " << pDoctor->getDescriptionInfo() << " " << pDoctor->getDocPostion_enum() << " " << pDoctor->getHospitalName()<< endl;
	
	//ˢ��
	file.flush();
	
	//�ر� 
	file.close();
	
	
} 

//����ҽ��
void CData::updataDoctor()
{
	//���ļ�
	fstream file ("data/doctor.txt",fstream::in | fstream::out | fstream::trunc);
	
	//��������д���ļ�  
	list<CDoctor*>::iterator it;
	for(it = CData::doctorList.begin(); it != CData::doctorList.end();++it)
	{
		file << (*it)->getId() << " " << (*it)->getUserName() << " " << (*it)->getPwd() << " " << (*it)->getRole() << " " << (*it)->getDepartment() 
		<< " " << (*it)->getDescriptionInfo() << " " << (*it)->getDocPostion_enum() << " " << (*it)->getHospitalName()<< endl;
	} 
	 
	//ˢ��
	file.flush();
	
	//�ر� 
	file.close();
	
	
	 
} 

//�������ݼ���
void CData::initPatient()
{
	fstream file("data/patient.txt",fstream::in | fstream::out | fstream::app);
	
	//
	if(file.is_open())
	{
		file.seekg(0,ios_base::end);
		int count = file.tellg();
		
		if(count <= 0)
		{
			list<CPatient*>::iterator it;
			CData::patientList.push_back(new CPatient(1001,"janice","123456",PATIENT,"12345678922","none"));
			CData::patientList.push_back(new CPatient(1002,"andrew","123456",PATIENT,"11111111111","none"));
			for(it = CData::patientList.begin(); it != CData::patientList.end(); ++it)
			{
				file << (*it)->getId() << " "<< (*it)->getUserName() << " " << (*it)->getPwd() << " "<< (*it)->getRole() << " "<< (*it)->getPhoneNum() << " " << (*it)->getIdentification() <<  endl;
			}
			
			
		}
		else
		{
			file.seekg(0,ios_base::beg);
			
			char buffer[256] = {0};
			int id =0 , role = 0;
			char name[10] ={0} , pwd[10] = {0};
			char phoneNum[12] = {0};
			char identification[19] = {0};
			
			while(file.peek() != EOF)
			{
				file.getline(buffer,50);
				
				sscanf(buffer,"%d %s %s %d %s %s",&id,name,pwd,&role,phoneNum,identification);
				
				CData::patientList.push_back(new CPatient(id,name,pwd,(Role)role,phoneNum,identification));
				
				
			}
			
			
			
		}		
		
	}
	else 
	{
		cout << "open file failed" <<endl;
	}
	
	file.close();
} 


//�������� 
void CData::addPatient(CPatient* pPatient) 
{
	fstream file ("data/patient.txt",fstream::in | fstream::out | fstream::app);
	
	file.seekg(0,ios_base::end);
	
	file<< pPatient->getId() << " "
		<< pPatient->getUserName() << " " 
		<< pPatient->getPwd() << " "
		<< pPatient->getRole() << " "
		<< pPatient->getPhoneNum() << " "
		<< pPatient->getIdentification() <<  endl;
	
	file.flush();
	
	file.close();
	
}

//���»��� 

void CData::updataPatient()
{
	fstream file ("data/patient.txt",fstream::in | fstream::out | fstream::trunc);
	
	file.seekg(0,ios_base::beg);
	
	//����д���ļ�
	list<CPatient*>::iterator it;
	for (it = CData::patientList.begin(); it != CData::patientList.end(); ++it)
	{
		file<< (*it)->getId() << " "
			<< (*it)->getUserName() << " " 
			<< (*it)->getPwd() << " "
			<< (*it)->getRole() << " "
			<< (*it)->getPhoneNum() << " "
			<< (*it)->getIdentification()<< endl;
	} 
	 
	file.flush();
	
	file.close();
	
	
	
} 

//ԤԼ����� 
void CData::initAppointment()
{	
	
	fstream file ("data/appointment.txt", fstream::in | fstream::out | fstream::app);
	
	if(file.is_open())
	{
		file.seekg(0,ios_base::end);
		int count = file.tellg();
		
		if(count<=0)
		{	
			list<CAppointment*>::iterator it;
			//�ɳ�ʼ����Ϣ--Ŀǰ�� 
			CData::appointmentList.push_back(new CAppointment(1001,"12222222222","2025��7��5��10:23:46","�ڿ�","����","2025��7��7��","14:00~17:00","ͷ��","�����ˮ",PENDINGAPPOINTMENT));
			for(it=CData::appointmentList.begin(); it!= CData::appointmentList.end();++it)
			{
				file << (*it)->getAppointmentId() << " " <<  (*it)->getPatientPhoneNum() << " " << (*it)->getOrderTime() << " " << (*it)->getDepartment() 
				<< " "<< (*it)->getDoctorName() << " " << (*it)->getAppointmentTime() << " " << (*it)->getAppointmentTurns() << " "<< (*it)->getSelfDescription()
				<< " " << (*it)->getDoctorDescription() << " " << (*it)->getAppointmentStatusInt() << endl; 
			}
			
			
		}
		else 
		{
			file.seekg(0,ios_base::beg);
			char buffer[256] = {0};
			int id = 0;
			char patientPhoneNum[12]={0};
			char orderTime [20] = {0};
			char department [20] = {0};
			char doctorName[15] = {0};
			char appointmentTime[20] = {0};
			char appointmentTurns[10] = {0};
			char selfDescription[50] = {0};
			char doctorDescription[70] = {0};
			int appointmentStatus=0;
			
			while(file.peek()!=EOF)
			{	
				file.getline(buffer,200);
				sscanf(buffer,"%d %s %s %s %s %s %s %s %s %d",&id,patientPhoneNum,orderTime,department,doctorName,appointmentTime,appointmentTurns,selfDescription,doctorDescription,&appointmentStatus);
				
				CData::appointmentList.push_back(new CAppointment(id,patientPhoneNum,orderTime,department,doctorName,appointmentTime,appointmentTurns,selfDescription,doctorDescription,(AppointmentStatus)appointmentStatus));
							
			}			
			
			
		}
		
		
			
	}
	else
	{
		cout << "open file failed" <<endl;
	}
	
	file.close();
	
	
}



//����ԤԼ
void CData::addAppointment(CAppointment* pAppointment)
{
	fstream file("data/appointment.txt",fstream::in | fstream::out | fstream::app);
	
	file.seekg(0,ios_base::end);
	
	file << pAppointment->getAppointmentId() << " " <<pAppointment->getPatientPhoneNum() << " " << pAppointment->getOrderTime() << " " << pAppointment->getDepartment() <<  " " 
				<< pAppointment->getDoctorName() << " " << pAppointment->getAppointmentTime() <<  " " << pAppointment->getAppointmentTurns() <<" " << pAppointment->getSelfDescription()
				<< " " << pAppointment->getDoctorDescription() << " " << pAppointment->getAppointmentStatusInt() << endl; 
	
	file.flush();
	
	file.close();
	
	
} 

//����ԤԼ
void CData::updateAppointment()
{
	fstream file ("data/appointment.txt",fstream::in| fstream::out | fstream::trunc);
	
	file.seekg(0,ios_base::beg);
	
	
	list<CAppointment*>::iterator it;
	
	for(it=CData::appointmentList.begin(); it!= CData::appointmentList.end();++it)
			{
				file << (*it)->getAppointmentId() << " " <<(*it)->getPatientPhoneNum() << " " << (*it)->getOrderTime() << " " << (*it)->getDepartment() 
				<< " "<< (*it)->getDoctorName() << " " << (*it)->getAppointmentTime() << " " << (*it)->getAppointmentTurns() << " "<< (*it)->getSelfDescription()
				<< " " << (*it)->getDoctorDescription() << " " << (*it)->getAppointmentStatusInt() << endl;
			}
	
	file.flush();
	
	file.close();
	
	
	
} 


//���������
void CData::initDepartment()
{
	fstream file ("data/department.txt",fstream::in| fstream::out | fstream::app);
	
	if(file.is_open())
	{
		file.seekg(0,ios_base::end);
		int count = file.tellg();
		if(count <= 0)
		{
			//��ʼ����Ϣ
			CData::deparmentVec.push_back(new CDepartment(1001,"�ڿ�","��Ѫ���ڿ�")); 
			CData::deparmentVec.push_back(new CDepartment(1002,"���","��ͨ���")); 
			CData::deparmentVec.push_back(new CDepartment(1003,"������","��ʹ����"));
			//����vector д���ļ� 
			vector<CDepartment*>::iterator it;
			for(it = CData::deparmentVec.begin(); it!= CData::deparmentVec.end();++it)
			{
				file << (*it)->getDepartmentId() << " " << (*it)->getDepartmentName() << " " << (*it)->getDepartmentInfo() << endl;
			}
			
			
			
			 
		}
		else 
		{	
			file.seekg(0,ios_base::beg);
			char buffer[256] = {0};
			int id = 0;
			char departmentName[15] ={0};
			char departmentInfo[25] ={0};
			
			while(file.peek()!=EOF)
			{
				file.getline(buffer,60);
				sscanf(buffer,"%d %s %s",&id,departmentName,departmentInfo);
				
				CData::deparmentVec.push_back(new CDepartment(id,departmentName,departmentInfo));
				
				
			}
			
				
			
			
		}
						
	}
	else 
	{
		cout << "file open failed" << endl;
	}
	
	file.close();	
	
} 

void CData::addDepartment(CDepartment* pDepartment)
{
	fstream file ("data/department.txt",fstream::in| fstream::out | fstream::app);
	
	file.seekg(0,ios_base::end);
	
	file << pDepartment->getDepartmentId() << " " << pDepartment->getDepartmentName() << " " << pDepartment->getDepartmentInfo() << endl;
	
	file.flush();
	
	file.close();
	
}

void CData::updateDepartment()
{
	fstream file("data/department.txt",fstream::in | fstream::out | fstream::trunc);
	
	vector<CDepartment*>::iterator it;
	//����
	for(it = CData::deparmentVec.begin(); it!= CData::deparmentVec.end();++it)
		{
			file << (*it)->getDepartmentId() << " " << (*it)->getDepartmentName() << " " << (*it)->getDepartmentInfo() << endl;
		}
	
	file.flush();
	
	file.close();
	
	
	
} 



void CData::initBookingTime()
{	
	//��ʼ��δ��7�� 
	CData::currentYmdVec.push_back(CTools::getOneDayAfterDayTime(1));
	CData::currentYmdVec.push_back(CTools::getOneDayAfterDayTime(2));
	CData::currentYmdVec.push_back(CTools::getOneDayAfterDayTime(3));
	CData::currentYmdVec.push_back(CTools::getOneDayAfterDayTime(4));
	CData::currentYmdVec.push_back(CTools::getOneDayAfterDayTime(5));
	CData::currentYmdVec.push_back(CTools::getOneDayAfterDayTime(6));
	CData::currentYmdVec.push_back(CTools::getOneDayAfterDayTime(7));
	
	//ÿ���ԤԼʱ�� 
	CData::dayTimeHmdVec.push_back("09:00~10:00");
	CData::dayTimeHmdVec.push_back("14:00~17:00");

	
}

































