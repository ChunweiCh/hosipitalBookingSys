#ifndef _CBUTTON_H
#define _CBUTTON_H

#include "CTools.h"
#include <cstring>
#include <iostream>

#include "ctrlBase.h"
using namespace std;


class CButton : public CtrlBase
{
	public:
	CButton(int x, int y, int width , int height,string content,CONTROL ctrlType);
	~CButton();
	void show();
	private:
		
	

		

		
};





#endif
