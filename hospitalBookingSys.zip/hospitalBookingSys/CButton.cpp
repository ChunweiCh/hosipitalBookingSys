#include "CButton.h"





CButton::CButton(int x, int y, int width, int height, string content,CONTROL ctrlType)
:CtrlBase(x,y,width,height,content,ctrlType)
{


	
	
}

CButton::~CButton()
{
	
}

void CButton::show()
{
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	CTools::gotoxy(this->x+3,this->y+1);
	cout << this->content;

  
	
}
