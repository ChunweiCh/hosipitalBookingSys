#include "CPatientTreatmentWin.h"





//���������� --������Ϣ����
CPatientTreatmentWin::CPatientTreatmentWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->findAppointmentMember = findAppointmentMember;
	this->title = new CLabel(46,1,0,0,"������Ϣ����",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ,��ͨ�û�",LABEL);
	this->timeShowLabel = new CLabel(58,4,0,0,"����: ",LABEL);
	this->enterUserIdNoticeLabel = new CLabel(5,7,0,0,"�������������: ",LABEL);
	this->upDownPageNoticeLabel = new CLabel(85,19,0,0,"�� �� �� ��ҳ",LABEL);
	
	this->frontDateEdit = new CEdit(25,7,20,3,"",EDIT,15,1,3);
	this->orLabel = new CLabel(47,7,0,0,"��",LABEL);
	this->endDateEdit = new CEdit(52,7,20,3,"",EDIT,15,1,3);
	
	
	

	
	this->searchBtn = new CButton(74,7,10,3,"��ѯ",BUTTON);
	//��ͷ
	this->tableHead = tableHead;
	tableHead.push_back(" ԤԼ���    ");//ID 
	tableHead.push_back("         ����ʱ��         ");
	tableHead.push_back(" ����ҽԺ");
	tableHead.push_back(" ������� ");
	tableHead.push_back(" ҽ��  ");
	tableHead.push_back(" ����״̬" );
	
	
	
	
	
	this->treatmentTable = new CTable(10,10,0,0,"",TABLE,this->tableHead); 
	
	this->row1Btn = new CButton(5,12,0,0,"",BUTTONDYNAMIC);
	this->row2Btn = new CButton(5,14,0,0,"",BUTTONDYNAMIC);
	this->row3Btn = new CButton(5,16,0,0,"",BUTTONDYNAMIC);
	this->returnBtn = new CButton(10,19,10,3,"����",BUTTON); 
	
	this->addCtrl(title); 
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(enterUserIdNoticeLabel);
	this->addCtrl(upDownPageNoticeLabel);
	
	this->addCtrl(frontDateEdit); //5
	this->addCtrl(orLabel);
	this->addCtrl(endDateEdit);
	

	this->addCtrl(searchBtn); //8
	this->addCtrl(treatmentTable);
	
	this->addCtrl(row1Btn);//10
	this->addCtrl(row2Btn);//11
	this->addCtrl(row3Btn);//12
	this->addCtrl(returnBtn); //13
	
}




CPatientTreatmentWin::~CPatientTreatmentWin()
{
	
}
	
int CPatientTreatmentWin::doAction()
{
	switch(this->ctrlIndex)
	{
		//��ѯ 
		case 8:
			{
				string  frontDateInput = this->frontDateEdit->getContent();
				string  endDateInput = this->endDateEdit->getContent();
				
				//������֤
				if(frontDateInput.empty() || endDateInput.empty())
				{
					 CTools::gotoxy(0,28);
					 cout << "�������������ݽ�������,���������롣��ʽΪYYYYMMDD,20251022" << endl;
					 getch();
					  //����༭��
					 this->frontDateEdit->EditClear();
					 this->endDateEdit->EditClear(); 
					 return TREATMENTWIN; 
				} 
				else if(!CTools::isValiInputDate(frontDateInput)|| !CTools::isValiInputDate(endDateInput))
				{
					CTools::gotoxy(0,28);
					 cout << "���ڸ�ʽ����,��ʹ��YYYYMMDD,20250712" << endl;
					 getch();
					 //����༭��
					 this->frontDateEdit->EditClear();
					 this->endDateEdit->EditClear(); 
					  
					 return TREATMENTWIN; 
				}
				else if(frontDateInput > endDateInput)
				{
					CTools::gotoxy(0,28);
					 cout << "��ʼ���ڲ������ڽ�������" << endl;
					 getch();
					 //����༭��
					 this->frontDateEdit->EditClear();
					 this->endDateEdit->EditClear(); 
					  
					 return TREATMENTWIN; 
				}
				
				
				//ÿ�����ض�Ҫ���findmember������
				
				this->findAppointmentMember.clear();
				
				list<CAppointment*>::iterator it;
				for(it = CData::nowUserAppointment.begin(); it != CData::nowUserAppointment.end();++it)
				{	 
					string chineseDate = (*it)->getAppointmentTime();
					string appointmentDate = CTools::chineseDateToNumber(chineseDate);//ת�ɴ����� 
					if(appointmentDate.empty()) continue;
					//�ж������Ƿ����м� 
					if(appointmentDate >= frontDateInput && appointmentDate <= endDateInput)
					{
						findAppointmentMember.push_back(*it);
					}
					 
				}
				//��ѯ�ж�
				if(findAppointmentMember.empty())
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->treatmentTable->setPageIndex(1);
					
					CTools::gotoxy(0,28);
					cout << "û���ҵ�" + frontDateInput + "��" + endDateInput + "֮���ԤԼ" << endl;
					getch();
					
					
					//����༭��
					 this->frontDateEdit->EditClear();
					 this->endDateEdit->EditClear(); 
					  
					 return TREATMENTWIN; 
				}
				else 
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->treatmentTable->setPageIndex(1);
					return TREATMENTWIN; 
				}
				
			}
			
		
		case 10:

		case 11:

		case 12: 
		{
			 // ȷ����ǰ��ʾ������Դ
		    list<CAppointment*>& currentList = this->findAppointmentMember.empty() 
		                                ? CData::appointmentList 
		                                : this->findAppointmentMember;
		    
		    // ��ȡ��ǰҳ��3��ҽ������
		    list<CAppointment*> currentPageAppointment = this->treatmentTable->getCurrentPageAppointment(currentList);/////////
		    
		    // ����ѡ�е������� (9��0, 10��1, 11��2)
		    int selectedRow = this->ctrlIndex - 10;
		    
		    // ��ȡѡ�е�ҽ��
		    list<CAppointment*>::iterator it = currentPageAppointment.begin();
		    advance(it, selectedRow);
		    
		    if (it != currentPageAppointment.end() && *it != NULL) 
			{	
				CData::selectedAppointment = NULL;
				list<CAppointment*>::iterator it2;
				for(it2 = CData::appointmentList.begin(); it2 != CData::appointmentList.end(); ++it2)
				{	
					if((*it2)->getAppointmentId() == (*it)->getAppointmentId())
					{
						CData::selectedAppointment = *it2;
						break;
					} 
						
				} 
		        if(!CData::selectedAppointment)
		        {//����δ�ҵ������ 
		        	return TREATMENTWIN;
				}
		        
		        //ҵ���߼�  
				return PATIENTRECORDWIN;
		       

		    }
		    
					
			return TREATMENTWIN;
			
		}
		
		//����	
		case 13:
			{ 
				//����༭��
			
			 this->frontDateEdit->EditClear();
			 this->endDateEdit->EditClear(); 
			this->treatmentTable->setPageIndex(1);
			return PATIENTWIN;
			}
		case -2:
			return TREATMENTWIN;
	}
	
	
	
}
	
void CPatientTreatmentWin::showWin()
{
	
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		
	
	
	if(this->findAppointmentMember.empty())
	{
		this->treatmentTable->showTreatmentData(CData::nowUserAppointment);	
		this->treatmentTable->showPage(3,CData::nowUserAppointment.size());
	}
	else
	{
		this->treatmentTable->showTreatmentData(this->findAppointmentMember);	
		this->treatmentTable->showPage(3,this->findAppointmentMember.size());
	}	

}



void CPatientTreatmentWin::winRun()
{
    int i=0, key= 0;
  
    
    // �ҵ���ʼ�۽��Ŀؼ�
    for (i=0; i<this->ctrlCount; i++)
    {
        if (this->ctrlArr[i]->getCtrlType() == EDIT)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                          this->ctrlArr[i]->getY()+1);
            break;
        }
        else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                 this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
            // Set arrow immediately for dynamic buttons
            if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
            {
                static_cast<CButton*>(this->ctrlArr[i])->setContent("��");
                this->ctrlArr[i]->show();
                
            }
            break;
        }
    }
    
    // ���浱ǰ�۽����а�ťָ��
    CButton* currentRowBtn = NULL;
    if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
    {
        currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
    }
    // ������������ 
    while (1)
    {
        key = CTools::getKey();
        switch(key)
        {
            case KEY_DOWN:
            {	
            	// �����ǰ�а�ť�ļ�ͷ
                if (currentRowBtn != NULL)
                {
                    currentRowBtn->setContent("");
                    currentRowBtn->show();
                    currentRowBtn = NULL;
                }
                
                i++;
                if (i == this->ctrlCount) i = 0;
                
                while(1)
                {
                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
                    {	
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                                      this->ctrlArr[i]->getY()+1);
                        break;
                    }
                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
                    {
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
                        // ������а�ť����ʾ��ͷ
                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
                        {
                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
                            currentRowBtn->setContent("��");
                            currentRowBtn->show();
                            showWin();
                        }
                        break;
                    }
                    i++;
                    if (i == this->ctrlCount) i = 0;
                }
                break;
			}
				    
                
                
            case KEY_UP:
                {	
                	// �����ǰ�а�ť�ļ�ͷ
	                if (currentRowBtn != NULL)
	                {
	                    currentRowBtn->setContent("");
	                    currentRowBtn->show();
	                    currentRowBtn = NULL;
	                }
                	i--;
	                if (i < 0) i = this->ctrlCount - 1;
	                
	                while(1)
	                {
	                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
	                                      this->ctrlArr[i]->getY()+1);
	                        break;
	                    }
	                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
	                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
	                         // ������а�ť����ʾ��ͷ
	                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
	                        {
	                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
	                            currentRowBtn->setContent("��");
	                            currentRowBtn->show();
	                            showWin();
	                        }
	                        
	                        break;
	                    }
	                    i--;
	                    if (i < 0) i = this->ctrlCount - 1;
	                }
	                break;
				}
                
                
                
            case KEY_RIGHT:
            	{
            		this->treatmentTable->showNextPage();
	                this->ctrlIndex = -2;
	                return;
				}
                
                
            case KEY_LEFT:
                this->treatmentTable->showLastPage();
                this->ctrlIndex = -2;
                return;
                
            case KEY_ENTER:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                    this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                {
	                    this->ctrlIndex = i;
	                    return;
	                }
	                break;
				}
                
                
            default:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                {    
	                    static_cast<CEdit*>(ctrlArr[i])->editKeyListen((char)key);
	                }
	                break;
				}
                
        }
    }
}








