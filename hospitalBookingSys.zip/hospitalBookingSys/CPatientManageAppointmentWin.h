#ifndef _CPATIENTMANAGEAPOINTMENTWIN_H_
#define _CPATIENTMANAGEAPOINTMENTWIN_H_

#include "windowBase.h"
#include "ctrlBase.h"

#include "CData.h"

class CPatientManageAppointmentWin : public WinBase
{	
	public:
		CPatientManageAppointmentWin();
		CPatientManageAppointmentWin(int x, int y, int w, int h);
		~CPatientManageAppointmentWin(); 
		void showWin();
		int doAction();
		
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShow;//���ڵ�ʱ��
	
	CButton* startAppointmentBtn;
	CButton* bookingVaccineBtn;
	CButton* getVaccineListBtn;
	CButton* returnBtn;
	

		
		
	
};





#endif
