#include "CPatientStartBookingWin.h"





CPatientStartBookingWin::CPatientStartBookingWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(26,1,0,0,"ԤԼ�������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ,��ͨ�û�",LABEL);
	this->timeShow = new CLabel(42,4,0,0,"����: ",LABEL);
		
	this->selectHospitalLabel = new CLabel(7,7,0,0,"ѡ��ҽԺ: ",LABEL);
	this->selectDepartmentLabel = new CLabel(7,10,0,0,"ѡ�����: ",LABEL);
	this->selectDoctorLabel = new CLabel(7,13,0,0,"ѡ��ҽ��: ",LABEL);
	this->selcetBookingTimeLabel = new CLabel(7,16,0,0,"ѡ��ʱ��: ",LABEL);
	this->patientInfoLabel = new CLabel(7,19,0,0,"��    ��: ",LABEL);
	
	this->hospitalShow = new CLabel(20,7,40,3,"����ҽԺ",LABEL);
	this->departmentBoxShow = new CLabel(20,10,40,3,"",LABEL);
	this->doctorBoxShow = new CLabel(20,13,40,3,"",LABEL);
	this->ymdBoxShow = new CLabel(20,16,20,3,"",LABEL);
	this->dayTimeBookingBoxShow = new CLabel(41,16,19,3,"",LABEL);
	
	this->patientInfoEdit = new CEdit(20,19,40,3,"",EDIT,20,1,4);
	
	this->departmentBoxBtn = new CButton(54,10,0,0,"��",BUTTON);
	this->doctorBoxBtn = new CButton(54,13,0,0,"��",BUTTON);
	this->ymdBoxBtn = new CButton(34,16,0,0,"��",BUTTON);
	this->bookingDayTimeBoxBtn = new CButton(54,16,0,0,"��",BUTTON);
	
	this->confirmBtn = new CButton(17,22,10,3," ȷ�� ",BUTTON);//18
	this->returnBtn = new CButton(33,22,10,3," ȡ�� ",BUTTON);//19
	
	//�������ʼ��
	this->departmentBoxVec = departmentBoxVec;
	//���������� 
	vector <CDepartment*>::iterator it;
	for (it = CData::deparmentVec.begin(); it !=CData::deparmentVec.end();++it)
	{
		departmentBoxVec.push_back((*it)->getDepartmentName());
	}
		
	
	//ҽ��������
	this->doctorBox = doctorBox;

	//������������ 
	this->ymdBox = ymdBox;
	vector<string>::iterator it1;
	for(it1 = CData::currentYmdVec.begin(); it1 != CData::currentYmdVec.end();++it1)
	{
		ymdBox.push_back((*it1));
	}

	//ÿ��ʱ�������� 
	this->dayTimeBox = dayTimeBox;
	vector<string>::iterator it2;
	for(it2 = CData::currentYmdVec.begin(); it2 != CData::currentYmdVec.end();++it2)
	{
		dayTimeBox.push_back((*it2));
	}	 

	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShow);
	this->addCtrl(selectHospitalLabel);
	this->addCtrl(selectDepartmentLabel);
	this->addCtrl(selectDoctorLabel);
	this->addCtrl(selcetBookingTimeLabel);
	this->addCtrl(patientInfoLabel);
	this->addCtrl(hospitalShow);
	this->addCtrl(departmentBoxShow);
	this->addCtrl(doctorBoxShow);
	this->addCtrl(ymdBoxShow);
	this->addCtrl(dayTimeBookingBoxShow);
	this->addCtrl(departmentBoxBtn);//13
	this->addCtrl(doctorBoxBtn);//14
	this->addCtrl(ymdBoxBtn);//15
	this->addCtrl(bookingDayTimeBoxBtn);//16
	this->addCtrl(patientInfoEdit);//17
	this->addCtrl(confirmBtn);//18
	this->addCtrl(returnBtn);//19
	




}


CPatientStartBookingWin::~CPatientStartBookingWin()
{
	
}




int CPatientStartBookingWin::doAction()
{
	static int result = 0;
	switch(this->ctrlIndex)
	{	//����������ѡ�� 
		
		case 13:
			{	
				//����������ֵ��ť
		 
				WinBase* departmentBoxWin = new CComboBox(20,12,40,0,departmentBoxVec);
				
				departmentBoxWin->showWin();
				departmentBoxWin->winRun();
				result = departmentBoxWin->doAction();
				delete departmentBoxWin;
				switch(result)
				{
					case 1:
						this->departmentBoxShow->setContent("�ڿ�"); 
						break;
					case 2:
						this->departmentBoxShow->setContent("���"); 
						break;
					case 3:
						this->departmentBoxShow->setContent("������"); 
						break;
					
					
				}	
				this->doctorBoxShow->setContent("");
				this->ymdBoxShow->setContent("");
				this->dayTimeBookingBoxShow->setContent("");
				
				return PATIENTSTARTBOOKINGWIN;	
			}
			
		//ҽ��������ѡ�� 
		case 14:
			{	
				//ÿ�δ����������doctorBox
				this->doctorBox.clear();
				//�ж����ѡ�����ֻ��ʾ��Ӧ���ҵ�ҽ��
				//������û����ѡ���ʱ�򿴲���ҽ�� 
				
				list<CDoctor*>::iterator it1;
				for(it1 = CData::doctorList.begin(); it1 != CData::doctorList.end();++it1)
				{	
					if(this->departmentBoxShow->getContent().size()==0)
					{	
						this->doctorBoxShow->setContent("��ҽ������ѡ����");
						return PATIENTSTARTBOOKINGWIN;
					 	
					}
					else if(this->departmentBoxShow->getContent()==(*it1)->getDocPostionString())
					{	
						
						this->doctorBox.push_back((*it1)->getUserName()); 
						
					}
					else
					{	
						//Ԥ��Ұָ�� 
						
						this->doctorBoxShow->setContent("�����ҽ��");
					}
					
				}
				
				
				
				
				 
				WinBase* doctorBoxWin = new CComboBox(20,15,40,2,doctorBox);
				
				doctorBoxWin->showWin();
				doctorBoxWin->winRun();
				result = doctorBoxWin->doAction();
				
				switch(result)
				{
					case 1:
						this->doctorBoxShow->setContent(doctorBox[0]); 
						break;
					case 2:
						this->doctorBoxShow->setContent(doctorBox[1]); 
						break;
					case 3:
						this->doctorBoxShow->setContent(doctorBox[2]); 
						break;

					
				}
					
				delete doctorBoxWin;
				return PATIENTSTARTBOOKINGWIN;	
				
				
				
			}
		//δ��7��ԤԼʱ�� 
		case 15:
			{	
//				//ÿ�ε㿪Ҫ���ָ��
				this->dayTimeBookingBoxShow->setContent("");
//				ymdBox.clear();
				if(this->departmentBoxShow->getContent().empty() | this->doctorBoxShow->getContent().empty()) 
				{
					CTools::gotoxy(0,27);
					cout << "����ѡ����Һ�ҽ������ԤԼʱ�䣬�����³���" << endl;
					getch();
					return  PATIENTSTARTBOOKINGWIN;
				}
				
				//��ʼ��δ��7��
				ymdBox = CData::currentYmdVec; 
				
				
				
				//�����򴰿� 
				
				WinBase* ymdComboBox = new CComboBox(20,18,20,2,ymdBox);
				 
				ymdComboBox->showWin();
				ymdComboBox->winRun();
				int result = ymdComboBox->doAction();
				delete ymdComboBox;
				
				switch(result)
				{
					case 1:
						this->ymdBoxShow->setContent(ymdBox[0]); 
						break;
					case 2:
						this->ymdBoxShow->setContent(ymdBox[1]); 
						break;
					case 3:
						this->ymdBoxShow->setContent(ymdBox[2]); 
						break;
					case 4:
						this->ymdBoxShow->setContent(ymdBox[3]); 
						break;
					case 5:
						this->ymdBoxShow->setContent(ymdBox[4]); 
						break;
					case 6:
						this->ymdBoxShow->setContent(ymdBox[5]); 
						break;
					case 7:
						this->ymdBoxShow->setContent(ymdBox[6]); 
						break;
					
				}
				
				return  PATIENTSTARTBOOKINGWIN;
				 
			}
		//ÿ���ʱ��� 
		case 16:
			{	
				
				string selectedDay = ymdBoxShow->getContent();
				string selectedDoctor = doctorBoxShow->getContent();
				string currentUserPhone = CData::nowUser->getPhoneNum(); // ��ǰ�û��ֻ��ţ�1222��
				
				// ��ʼ������ʱ���
				dayTimeBox = CData::dayTimeHmdVec;
				
				// ��鵱ǰ�����ڸ�ҽ��+���ڵ���ԤԼʱ��
				list<string> bookedTimes;
				list<CAppointment*>::iterator it; 
				for (it = CData::appointmentList.begin(); it != CData::appointmentList.end(); ++it) {
				    if ((*it)->getPatientPhoneNum() == currentUserPhone &&  // ֻ��鵱ǰ����
				        (*it)->getAppointmentTime() == selectedDay && 
				        (*it)->getDoctorName() == selectedDoctor) {
				        bookedTimes.push_back((*it)->getAppointmentTurns());
				    }
				}
				
				 // �Ƴ���ǰ������ԤԼ��ʱ��
			    list<string>::iterator bookedIt;
			    for (bookedIt = bookedTimes.begin(); bookedIt != bookedTimes.end(); ++bookedIt) {
			        vector<string>::iterator timeIt;
			        for (timeIt = dayTimeBox.begin(); timeIt != dayTimeBox.end(); ) {
			            if (*timeIt == *bookedIt) {
			                timeIt = dayTimeBox.erase(timeIt);
			            } else {
			                ++timeIt;
			            }
			        }
			    }
				
				// ���û�п���ʱ��
				if (dayTimeBox.empty()) {
				    dayTimeBookingBoxShow->setContent("����");
				    return PATIENTSTARTBOOKINGWIN;
				}
				
				// ��ʾ��ѡʱ��ε�������
				WinBase* timeComboBox = new CComboBox(41, 18, 19, 2, dayTimeBox);
				timeComboBox->showWin();
				timeComboBox->winRun();
				int result = timeComboBox->doAction();
				delete timeComboBox;
				
				if (result >= 1 && result <= dayTimeBox.size()) {
				    dayTimeBookingBoxShow->setContent(dayTimeBox[result - 1]);
				}
				
				return PATIENTSTARTBOOKINGWIN;
			}
		//ȷ��
		case 18:
			{	
				if(this->departmentBoxShow->getContent().empty() | this->doctorBoxShow->getContent().empty()|
				this->ymdBoxShow->getContent().empty()| this->dayTimeBookingBoxShow->getContent().empty() |
				this->patientInfoEdit->getContent().empty())
				{
					CTools::gotoxy(0,27);
					cout << "������ȫ����Ϣ�������³���" << endl;
					getch();
					return  PATIENTSTARTBOOKINGWIN;
				}
				else if(this->dayTimeBookingBoxShow->getContent()=="����")
				{
					CTools::gotoxy(0,27);
					cout << "ʱ�������,������ѡ��ʱ��" << endl;
					getch();
					this->ymdBoxShow->setContent("");
					this->dayTimeBookingBoxShow->setContent("");
					return  PATIENTSTARTBOOKINGWIN;
				}
				else
				{
					//ԤԼ�ɹ�--��ȡ��״̬
					//�������� 
					string nowUserPhone = CData::nowUser->getPhoneNum();
					//ID����
					int newAppointmentId = CData::appointmentList.size()==0? 1001: CData::appointmentList.back()->getAppointmentId()+1;
					//�������� 
					CData::appointmentList.push_back(new CAppointment(newAppointmentId,nowUserPhone,(CTools::getCurrentTime()+CTools::getCurrentHMS()),this->departmentBoxShow->getContent(),
					this->doctorBoxShow->getContent(),this->ymdBoxShow->getContent(),this->dayTimeBookingBoxShow->getContent(),this->patientInfoEdit->getContent(),"none",PENDINGAPPOINTMENT));
					
					CData::nowUserAppointment.push_back(new CAppointment(newAppointmentId,nowUserPhone,(CTools::getCurrentTime()+CTools::getCurrentHMS()),this->departmentBoxShow->getContent(),
					this->doctorBoxShow->getContent(),this->ymdBoxShow->getContent(),this->dayTimeBookingBoxShow->getContent(),this->patientInfoEdit->getContent(),"none",PENDINGAPPOINTMENT));
					//д���ļ�
					CData::addAppointment(CData::appointmentList.back());
					
					//�ɹ���ʾ
					CTools::gotoxy(0,27);
					cout << "ԤԼ�ɹ�����ȥȡ��!" << endl;
					getch();
					//�������
					this->departmentBoxShow->setContent("");
					this->doctorBoxShow->setContent(""); 
					this->ymdBoxShow->setContent("");
					this->dayTimeBookingBoxShow->setContent("");
					this->patientInfoEdit->EditClear(); 
					return PATIENTBOOKINGMANAGEWIN; 
					 
				}
				
			}
		//����
		case 19:
			{	
				//�������
				this->departmentBoxShow->setContent("");
				this->doctorBoxShow->setContent(""); 
				this->ymdBoxShow->setContent("");
				this->dayTimeBookingBoxShow->setContent("");
				this->patientInfoEdit->EditClear(); 
				return PATIENTBOOKINGMANAGEWIN;
			}	
	} 


}



void CPatientStartBookingWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShow->setContent("����: "+CTools::getCurrentTime()); 
	
	//��ʾ�����û����ֻ���
	
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

	
}


