#ifndef _CPATIENTRECORDWIN_H_
#define _CPATIENTRECORDWIN_H_

#include "windowBase.h"
#include "ctrlBase.h"


#include "CData.h"


// ���� --������Ϣ--�����¼ 
class CPatientRecordWin :public WinBase
{
	public:
		CPatientRecordWin();
		CPatientRecordWin(int x, int y, int w, int h);
		~CPatientRecordWin();
		
			
		void showWin(); 
		int doAction();
		
		
	private:
	
	CLabel* title;
	CLabel* noticeLabel;
	CLabel* timeShowLabel;
	
	CLabel* patientIdLabel;
	CLabel* patientIdShow;
	CLabel* appointmentPatientDesLabel;
	CLabel* doctorDescriptionLabel;
	
	CLabel* appointmentPatientDesEdit;
	CLabel* doctorDescriptionEdit;
	
	CButton* confirmBtn;
	CButton* returnBtn;
	bool editFlag;
	
		
};







#endif
