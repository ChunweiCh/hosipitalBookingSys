#include "CManageDoctorWin.h"




CManageDoctorWin::CManageDoctorWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->findDoctorMember = findDoctorMember;
	this->title = new CLabel(36,1,0,0,"ҽ����������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ, admin, ����Ա",LABEL);
	this->timeShowLabel = new CLabel(58,4,0,0,"����: ",LABEL);
	this->enterUserIdNoticeLabel = new CLabel(5,7,0,0,"������ҽ������: ",LABEL);
//	this->upDownPageNoticeLabel = new CLabel(57,19,0,0,"�� �� �� ��ҳ",LABEL);
	
	this->enterUserIdEdit = new CEdit(25,7,30,3,"",EDIT,10,1,4);
	
	this->searchBtn = new CButton(57,7,10,3,"��ѯ",BUTTON);
	//��ͷ
	this->tableHead = tableHead;
	tableHead.push_back("ҽ��ID");
	tableHead.push_back("ҽ������");
	tableHead.push_back("��������");
	tableHead.push_back("  ְλ   ");
	tableHead.push_back("����ҽԺ");
	tableHead.push_back("���");
	this->doctorTable = new CTable(10,10,0,0,"",TABLE,tableHead); 
	this->addDoctorBtn = new CButton(68,7,12,3,"����ҽ��",BUTTON);
	this->row1Btn = new CButton(5,12,0,0,"",BUTTONDYNAMIC);
	this->row2Btn = new CButton(5,14,0,0,"",BUTTONDYNAMIC);
	this->row3Btn = new CButton(5,16,0,0,"",BUTTONDYNAMIC);
	this->upPage = new CButton(35,19,12,3,"��һҳ",BUTTON); 
	this->downPage = new CButton(50,19,12,3,"��һҳ",BUTTON);
	this->returnBtn = new CButton(10,19,10,3,"����",BUTTON); 
	
	this->addCtrl(title); 
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(enterUserIdNoticeLabel);
//	this->addCtrl(upDownPageNoticeLabel);
	this->addCtrl(enterUserIdEdit);
	this->addCtrl(searchBtn); //6
	this->addCtrl(doctorTable);//7
	this->addCtrl(addDoctorBtn);//8
	this->addCtrl(row1Btn);//9
	this->addCtrl(row2Btn);//10
	this->addCtrl(row3Btn);//11
	this->addCtrl(upPage); //12
	this->addCtrl(downPage); //12
	this->addCtrl(returnBtn); //12
	
	
}




CManageDoctorWin::~CManageDoctorWin()
{
	
}
	
int CManageDoctorWin::doAction()
{
	switch(this->ctrlIndex)
	{
		//��ѯ 
		case 6:
			{
				string doctorName = this->enterUserIdEdit->getContent();
				//ÿ�����ض�Ҫ���findmember������
				
				this->findDoctorMember.clear();
				list<CDoctor*>::iterator it;
				for(it = CData::doctorList.begin(); it != CData::doctorList.end();++it)
				{	 
					string doctorListName = (*it)->getUserName();
					if(doctorListName.find(doctorName)!= string::npos)
					{
						findDoctorMember.push_back(*it);
					}
					 
				}
				//��ѯ�ж�
				if(findDoctorMember.empty())
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->doctorTable->setPageIndex(1);
					
					this->enterUserIdEdit->setContent("δ�ҵ��������");
					this->enterUserIdEdit->show();
					getch();
					this->enterUserIdEdit->setContent("");
					this->enterUserIdEdit->show();
					return MANAGEDOCTORWIN;
				}
				else 
				{	
					//ÿ���Ѳ��Ҫ����һҳ
					this->doctorTable->setPageIndex(1);
					return MANAGEDOCTORWIN;
				}
				
			}
			
			//����ҽ�� 
		case 8:
			{
				return ADDDOCTORWIN;
			}
		//��һ�а�ť 
		case 9:
		//�ڶ��а�ť 
		case 10:
		//�����а�ť 	
		case 11: 
		{
			 // ȷ����ǰ��ʾ������Դ
		    list<CDoctor*>& currentList = this->findDoctorMember.empty() 
		                                ? CData::doctorList 
		                                : this->findDoctorMember;
		    
		    // ��ȡ��ǰҳ��3��ҽ������
		    list<CDoctor*> currentPageDoctors = this->doctorTable->getCurrentPageDoctors(currentList);/////////
		    
		    // ����ѡ�е������� (9��0, 10��1, 11��2)
		    int selectedRow = this->ctrlIndex - 9;
		    
		    // ��ȡѡ�е�ҽ��
		    list<CDoctor*>::iterator it = currentPageDoctors.begin();
		    advance(it, selectedRow);
		    
		    if (it != currentPageDoctors.end() && *it != NULL) {
		        CData::selectedDoctor = *it;
		        
		        //�༭ҽ�����߼�
		        
		       	return EDITDOCTORWIN;
//		        // ��ʱ��ӡѡ�е�ҽ����Ϣ
//		        CTools::gotoxy(10, 20);
//		        cout << "ѡ��ҽ��: " << CData::selectedDoctor->getUserName();
//		        getch();
		    }
		    return MANAGEDOCTORWIN;
					
			
			
			
		}
		
		//����	
		case 12:
			{ 
				this->enterUserIdEdit->EditClear();
				this->findDoctorMember.clear();
				this->doctorTable->setPageIndex(1);
				return ADMINWIN;
			}
		case -2:
			return MANAGEDOCTORWIN;
	}
	
	
	
}
	
void CManageDoctorWin::showWin()
{
	
	
	
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}

	
	if(this->findDoctorMember.empty())
	{
		this->doctorTable->showDoctorData(CData::doctorList);	
		this->doctorTable->showPage(3,CData::doctorList.size());
	}
	else
	{
		this->doctorTable->showDoctorData(this->findDoctorMember);	
		this->doctorTable->showPage(3,this->findDoctorMember.size());
	}	

}


void CManageDoctorWin::winRun()
{
    int i=0, key= 0;
  
    
    // �ҵ���ʼ�۽��Ŀؼ�
    for (i=0; i<this->ctrlCount; i++)
    {
        if (this->ctrlArr[i]->getCtrlType() == EDIT)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                          this->ctrlArr[i]->getY()+1);
            break;
        }
        else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                 this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
            // Set arrow immediately for dynamic buttons
            if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
            {
                static_cast<CButton*>(this->ctrlArr[i])->setContent("��");
                this->ctrlArr[i]->show();
                
            }
            break;
        }
    }
    
    // ���浱ǰ�۽����а�ťָ��
    CButton* currentRowBtn = NULL;
    if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
    {
        currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
    }
    // ������������ 
    while (1)
    {
        key = CTools::getKey();
        switch(key)
        {
            case KEY_DOWN:
            {	
            	// �����ǰ�а�ť�ļ�ͷ
                if (currentRowBtn != NULL)
                {
                    currentRowBtn->setContent("");
                    currentRowBtn->show();
                    currentRowBtn = NULL;
                }
                
                i++;
                if (i == this->ctrlCount) i = 0;
                
                while(1)
                {
                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
                    {	
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                                      this->ctrlArr[i]->getY()+1);
                        break;
                    }
                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
                    {
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
                        // ������а�ť����ʾ��ͷ
                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
                        {
                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
                            currentRowBtn->setContent("��");
                            currentRowBtn->show();
                            showWin();
                        }
                        break;
                    }
                    i++;
                    if (i == this->ctrlCount) i = 0;
                }
                break;
			}
				    
                
                
            case KEY_UP:
                {	
                	// �����ǰ�а�ť�ļ�ͷ
	                if (currentRowBtn != NULL)
	                {
	                    currentRowBtn->setContent("");
	                    currentRowBtn->show();
	                    currentRowBtn = NULL;
	                }
                	i--;
	                if (i < 0) i = this->ctrlCount - 1;
	                
	                while(1)
	                {
	                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
	                                      this->ctrlArr[i]->getY()+1);
	                        break;
	                    }
	                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
	                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
	                         // ������а�ť����ʾ��ͷ
	                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
	                        {
	                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
	                            currentRowBtn->setContent("��");
	                            currentRowBtn->show();
	                            showWin();
	                        }
	                        
	                        break;
	                    }
	                    i--;
	                    if (i < 0) i = this->ctrlCount - 1;
	                }
	                break;
				}
                
                
                
            case KEY_RIGHT:
            	{
            		this->doctorTable->showNextPage();
	                this->ctrlIndex = -2;
	                return;
				}
                
                
            case KEY_LEFT:
                this->doctorTable->showLastPage();
                this->ctrlIndex = -2;
                return;
                
            case KEY_ENTER:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                    this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                {
	                    this->ctrlIndex = i;
	                    return;
	                }
	                break;
				}
                
                
            default:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                {    
	                    static_cast<CEdit*>(ctrlArr[i])->editKeyListen((char)key);
	                }
	                break;
				}
                
        }
    }
}
















