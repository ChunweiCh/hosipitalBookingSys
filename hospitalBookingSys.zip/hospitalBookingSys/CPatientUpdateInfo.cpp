#include "CPatientUpdateInfo.h"





CPatientUpdateInfoWin::CPatientUpdateInfoWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(16,1,0,0,"��Ϣ���ƽ���",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ,��ͨ�û�",LABEL);
	this->timeShow = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->phoneNumLabel = new CLabel(11,7,0,0,"�ֻ�����: ",LABEL);
	this->phoneNumShow = new CLabel(21,7,0,0,"",LABEL);
	this->userNameLabel = new CLabel(11,10,0,0,"��    ��: ",LABEL);
	this->userIdentification = new CLabel(11,13,0,0,"����֤��: ",LABEL);
	
	this->userNameEdit = new CEdit(21,10,22,3,"",EDIT,10,1,4);
	this->userIdentificationEdit = new CEdit(21,13,22,3,"",EDIT,18,1,2);
	
	this->confirmBtn = new CButton(14,17,10,3," ȷ�� ",BUTTON);
	this->returnBtn = new CButton(27,17,10,3," ���� ",BUTTON);
	
	this->addCtrl(title); 
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShow);
	this->addCtrl(phoneNumLabel);
	this->addCtrl(phoneNumShow);
	this->addCtrl(userNameLabel);
	this->addCtrl(userIdentification);
	this->addCtrl(userNameEdit);
	this->addCtrl(userIdentificationEdit);
	this->addCtrl(confirmBtn);//9
	this->addCtrl(returnBtn);//10
	
	
	
} 

CPatientUpdateInfoWin::~CPatientUpdateInfoWin()
{
	
}

void CPatientUpdateInfoWin::showWin()
{
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShow->setContent("����: "+CTools::getCurrentTime()); 
	
	//��ʾ���ڵ��û��ֻ���
	this->phoneNumShow->setContent(CData::nowUser->getPhoneNum()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

}

int CPatientUpdateInfoWin::doAction()
{
	switch(this->ctrlIndex)
	{	
		//ȷ�� 
		case 9 :
			{	
				if(this->userNameEdit->getContent()==CData::nowUser->getUserName())
				{
					CTools::gotoxy(0,24);
					cout << "�û���һ�£�����������" << endl;
					getch();
					return UPDATEPATIENTINFOWIN; 
				}
				else if(this->userIdentificationEdit->getContent().size()<18)
				{
					CTools::gotoxy(0,24);
					cout << "��������ȷ��ʽ����֤��18λ" << endl;
					getch();
					return UPDATEPATIENTINFOWIN; 
				}
				else 
				{
					CData::nowUser->setUserName(this->userNameEdit->getContent());
					CData::nowUser->setIdentification(this->userIdentificationEdit->getContent());
					//���������е�����
					list<CPatient*>::iterator it;
					for(it = CData::patientList.begin(); it != CData::patientList.end();++it)
					{
						if(CData::nowUser->getId() == (*it)->getId())
						{
							(*it) = CData::nowUser;
							break;
						}
					} 
					//д���ļ�
					CData::updataPatient(); 
					
					CTools::gotoxy(0,24);
					cout << "�޸ĳɹ�" << endl;
					getch();
					return PATIENTWIN; 
					
				}
				
			}
		//����	
		case 10:
			{	
				//����༭������
				this->userNameEdit->EditClear();
				this->userIdentificationEdit->EditClear(); 
				return PATIENTCENTERWIN;
			}
			
	}
}


























