#include "CAppointment.h"








CAppointment::CAppointment(int appointmentId,string patientPhoneNum, string orderTime, string department, string doctorName
			,string appointmentTime,string appointmentTurns , string selfDescription, string doctorDescription, AppointmentStatus status	)
{	
	this->appointmentId = appointmentId;
	this->patientPhoneNum = patientPhoneNum;
	this->orderTime = orderTime;
	this->department = department;
	this->doctorName = doctorName;
	this->appointmentTime = appointmentTime;
	this->appointmentTurns = appointmentTurns;
	this->selfDescription = selfDescription;
	this->doctorDescription = doctorDescription;
	this->status = status;
	
	
	
}

CAppointment::~CAppointment()
{
	
}

//��ȡ

int CAppointment::getAppointmentId()
{
	return this->appointmentId;
}

string CAppointment::getPatientPhoneNum()
{
	return this->patientPhoneNum;
}

string CAppointment::getOrderTime()
{
	return this->orderTime;	
}

string CAppointment::getDepartment()
{
	return this->department;
}

string CAppointment::getDoctorName()
{
	return this->doctorName;	
}

string CAppointment::getAppointmentTime()
{
	return this->appointmentTime;
}

string CAppointment::getAppointmentTurns()
{
	return this->appointmentTurns;
}

string CAppointment::getSelfDescription()
{
	return this->selfDescription; 
}

string CAppointment::getDoctorDescription()
{
	return this->doctorDescription;	
}

string CAppointment::getAppointmentStatusString()
{
	switch(this->status)
	{
		case 1:
			return "��ȡ��";
			break;
		case 2:
			return "������";
			break;
		case 3:
			return "ȡ��ԤԼ";
			break;
		case 4:
			return "�Ѿ���";
			break;
		case 5:
			return "�ѹ���";
			break;
		default:
			break;
	}	
}

int CAppointment::getAppointmentStatusInt()
{
	return this->status; 
}

//���� 
void CAppointment::setPatientPhoneNum(string patientPhoneNum)
{
	this->patientPhoneNum = patientPhoneNum;
}

void CAppointment::setOrderTime(string orderTime)
{
	this->orderTime = orderTime;	
}

void CAppointment::setDepartment(string department)
{
	this->department = department;
}

void CAppointment::setDoctorName(string doctorName)
{
	this->doctorName = doctorName;	
}

void CAppointment::setAppointmentTime(string appointmentTime)
{
	this->appointmentTime = appointmentTime;
}

void CAppointment::setAppointmentTurns(string appintmentTurns)
{
	this->appointmentTurns = appointmentTurns;
}

void CAppointment::setSelfDescription(string selfDescription)
{
	this->selfDescription = selfDescription;	
}

void CAppointment::setDoctorDescription(string doctorDescription)
{
	this->doctorDescription = doctorDescription;
}

int CAppointment::setAppointmentStatusInt(AppointmentStatus status)
{
	this->status = status;
}










