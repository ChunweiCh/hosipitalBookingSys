#include "CComboBox.h"



CComboBox::CComboBox(int x, int y, int w, int h,vector<string>optionBtnVec)
:WinBase(x,y,w,h)
{	
	this->title = new CLabel(0,0,0,0,"",LABEL);
	this->addCtrl(title);
	
	
	this->optionBtnVec = optionBtnVec; 
	
	int count = 0;	
	for(int i=0; i<optionBtnVec.size();i++)
	{
		optionCButton.push_back(new CButton(this->x+2,this->y+count*2+1,0,0,optionBtnVec[i],BUTTON));
		
		this->addCtrl(optionCButton[i]);
		h+=3;
		this->height = h;
		count++;
	}
	
}



CComboBox::~CComboBox()
{
	
}
	
	



	
void CComboBox::showWin()
{
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		
	
	
}




int CComboBox::doAction()
{	
	switch(this->ctrlIndex)
	{
		case 1: 
				return 1;	
		case 2:
				return 2;
		case 3:
				return 3;
		case 4: 
				return 4;
		case 5: 
				return 5;
		case 6: 
				return 6;
		case 7: 
				return 7;
	}
	
	
		
		
}
















