#ifndef _CLOGINWIN_H_
#define _CLOGINWIN_H_

#include <list>
#include <string>
#include "CComboBox.h" 
#include "windowBase.h"
#include "CRoleSelectWin.h"
#include "CTools.h"

#include"CData.h"
#include "CUser.h"
#include "CDoctor.h"
#include "CPatient.h"

class CLoginWin:public WinBase
{
	public:
		CLoginWin();
		CLoginWin(int x, int y, int w, int h);
		~CLoginWin();
		
		int doAction();
		 
	private:
	CLabel* title;
	CLabel* userLabel;
	CLabel* pwdLabel;
	
	CLabel* roleLabel;
	CLabel* roleBoxLabel;
	//EDIT
	CEdit* userEdit;
	CEdit* pwdEdit;
	
	//BUTTON
	CButton* roleSelectBtn;//�������ܰ�ť 
	CButton* loginBtn;
	
	CButton* quitBtn;
	//��ɫ���������� 
	vector<string> comboBoxOp;
	protected:
		
		
};



#endif 
