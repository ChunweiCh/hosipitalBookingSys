#include "CUser.h"

CUser::CUser()
{
	
}

CUser::CUser(int id, string userName, string pwd,Role role)
{
	this->id = id;
	
	this->userName = userName;
	
	this->pwd = pwd;
	
	this->role = role;
	
	
	
}
CUser::~CUser()
{
	
}

int CUser::getId()
{
	return id;
}

string CUser::getUserName()
{
	return userName;
}

string CUser::getPwd()
{
	return pwd;
}



int CUser::getRole()
{
	return role;
}


//���� 
void CUser::setUserName(string name)
{
	this->userName = name;
}

void CUser::setPwd(string pwd)
{
	this->pwd = pwd;
}

void CUser::setRole(Role role)
{
	this->role = role;

}


void CUser::setUserId(int id)
{
	this->id = id; 
}









