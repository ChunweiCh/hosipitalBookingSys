#include "CBookingTime.h"


//��ʼ��ʱ������
 


 
CBookingTime::CBookingTime()
{	
	//��ȡ����ʱ��
	std::time_t now = std::time(NULL);
    std::tm date = *std::localtime(&now); 
    
	
	this->currentYmdVec = currentYmdVec;
	for(int i=1; i<8;i++)
	{
		currentYmdVec.push_back(CTools::getOneDayAfterDayTime(i));
	}
	
	
	this->dayTimeHmdVec = dayTimeHmdVec;
	
	dayTimeHmdVec.push_back("09:00~10:00");
	dayTimeHmdVec.push_back("14:00~17:00");
	
}












