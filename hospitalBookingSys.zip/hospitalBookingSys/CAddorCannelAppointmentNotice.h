#ifndef _CADDORCANNELAPPOINTMENT_H_ 
#define _CADDORCANNELAPPOINTMENT_H_


#include "windowBase.h"
#include "ctrlBase.h"
#include "CData.h"

#include <string>


class CAddorCannelAppointment: public WinBase
{
	public:
		CAddorCannelAppointment();
		CAddorCannelAppointment(int x, int y, int w, int h);
		~CAddorCannelAppointment(); 
		int doAction();
		void showWin();
		
	private:
		CLabel* title;
		CLabel* noticeLabel;
		CLabel* noticeShow;
		
		CButton* startBookingBtn;
		CButton* cannelAppointmentBtn;
		CButton* returnBtn; 
	
	
	
};
 



#endif
