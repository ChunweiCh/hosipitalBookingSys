#include "CPatient.h"



CPatient::CPatient()
{
	
}

CPatient::CPatient(int id , string userName, string pwd, Role role, string phoneNum,string identification)
:CUser(id,userName,pwd,role)
{	
	this->phoneNum = phoneNum;
	this->identification = identification; 
}

CPatient::~CPatient()
{
	
}

CPatient::CPatient(CPatient& other)
:CUser(other)
{
	this->phoneNum = other.phoneNum;
	
}

string CPatient::getPhoneNum()
{
	return this->phoneNum;
} 
string CPatient::getIdentification()
{
	return this->identification; 
}

void CPatient::setPhoneNum(string phoneNum)
{	
	
	this->phoneNum = phoneNum;
}

void CPatient::setIdentification(string identification)
{
	this->identification = identification;
}












