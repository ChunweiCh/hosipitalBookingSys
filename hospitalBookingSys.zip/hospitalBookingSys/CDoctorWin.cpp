#include "CDoctorWin.h"






CDoctorWin::CDoctorWin(int x, int y, int w , int h)
:WinBase(x,y,w,h)
{	

	
	this->title = new CLabel(16,1,0,0,"ҽ��������",LABEL);

	
	
	
	this->noticeLabel = new CLabel(3,4,0,0,"",LABEL);
	this->timeShowLabel = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->personalInfoBtn = new CButton(8,8,12,3,"��������",BUTTON);
	this->medicalConsultationBtn = new CButton(28,8,12,3,"������Ϣ",BUTTON);
	this->quitBtn = new CButton(8,11,12,3,"�˳�",BUTTON);

	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(personalInfoBtn); //3
	this->addCtrl(medicalConsultationBtn);//4
	this->addCtrl(quitBtn);//5

	
	
}

CDoctorWin::~CDoctorWin()
{
 
}


int CDoctorWin::doAction()
{	
	
	switch(this->ctrlIndex)
	{	//�������� 
		case 3:
			return DOCTORCENTERWIN;
		//������Ϣ 
		case 4:
			return DOCTORMEDICALCONSULTATIONWIN;
			
		//����
		case 5:
			return MAINWIN; 
	}
	return DOCTORWIN;
} 


void CDoctorWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	if(CData::nowDoctor != NULL)
	{
		welcomeNotice += CData::nowDoctor->getUserName();
	} 
	welcomeNotice += ", ҽ��";
	this->noticeLabel->setContent(welcomeNotice);
	
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

	
}














