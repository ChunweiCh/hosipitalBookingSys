#include "CEdit.h"



CEdit::CEdit(int x, int y, int width, int height,string content, CONTROL ctrlType,int maxlen, int mode,int inputType)
:CtrlBase(x,y,width,height,content,ctrlType)
{

	
	this->maxlen = maxlen;
	this->mode = mode;
	this->inputType = inputType;
	
	
	
	
}

CEdit::~CEdit()
{
	
}


int CEdit::getMaxlen()
{
	return maxlen;
}

int CEdit::getMode()
{
	return mode;
	
}

int CEdit::getInputType()
{
	return inputType;
}




void CEdit::editKeyListen(char ch)
{
	int len =static_cast<int>(this->content.size());
	
	if(ch == '\b')
	{	//char ���͵�ɾ������ 
		//this->content[--len] = '\0';
		if(len>0)
		{	//�����ʾ�������Ļ�ɾ 
			if(this->inputType ==4)
			{
				this->content.erase(static_cast<size_t>(len-2));
				
				printf("\b\b  \b\b");
			}
			else
			{
				this->content.erase(static_cast<size_t>(len-1));
		
				printf("\b \b");
			}
			
		}
		
		
		
	} 
	else if ((ch>='0'&&ch<='9')&& this->inputType==0)
	{//����0 
		if(len < this->maxlen)
		{
			this->content.push_back(ch);
			this->mode==0?putch('*'):putch(ch);
		}
	}
	else if ((ch>='A'&&ch<='Z'||ch>='a'&&ch<='z')&& this->inputType==1)
	{//����1 
		if(len < this->maxlen)
		{
			this->content.push_back(ch);	
			this->mode==0?putch('*'):putch(ch);
		}
	}
	else if ((ch>='0'&&ch<='9'||ch>='a'&&ch<='z'|| ch>='A'&& ch<='Z')&& this->inputType==2)
	{//����2 
		if(len<this->maxlen)
		{
			this->content.push_back(ch);
			this->mode==0?putch('*'):putch(ch);
		}
	}
	else if(this->inputType==3)
	{//����3 �������� 
		if (len<this->maxlen)
		{
			this->content.push_back(ch);
			this->mode==0?putch('*'):putch(ch);
		}
	}
	else if ((unsigned char)ch>=0xA1 && (unsigned char)ch<=0xFE && this->inputType == 4)
	{//����4 ���� 
		if (len <this->maxlen)
		{	
			char ch2;//�������ĵĵڶ����ַ� 
			 ch2 = getch();
			 if((unsigned char)ch2>=0xA1 && (unsigned char)ch2<=0xFE)
			 {
				this->content.push_back(ch);
				this->content.push_back(ch2);	
				if(this->mode==0)
				{
					putch('*');
					putch('*');
				}
				else if (this->mode==1)
				{
					cout << ch << ch2; 
				} 
						 	
			 }

	

			
			
			
		
			
			
		}
		
	}
	
	
	
}
//����༭�� 
void CEdit::EditClear()
{	
	this->content.clear();
	

	
}
void CEdit::show()
{	//
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	CTools::gotoxy(this->x+2,this->y+1);
	if(this->getMode()==0)
	{	
		for(int i=0; i < this->content.size(); i++)
		{
			cout << '*';
		}
		
	}
	else
	{
		cout << this->content;
	}
	
}






