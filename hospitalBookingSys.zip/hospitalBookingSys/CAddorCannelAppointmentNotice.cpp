#include "CAddorCannelAppointmentNotice.h"





CAddorCannelAppointment::CAddorCannelAppointment(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(45,10,0,0,"��ʾ:",LABEL);
	
	this->noticeLabel = new CLabel(49,12,0,0,"��ǰ�����Ŷ�0��!!!",LABEL);
	this->noticeShow = new CLabel(49,14,0,0,"",LABEL);
	this->startBookingBtn = new CButton(45,17,12,3,"ȡ��",BUTTON);
	this->cannelAppointmentBtn = new CButton(58,17,12,3,"ȡ��ԤԼ",BUTTON); 
	this->returnBtn = new CButton(73,17,12,3,"����",BUTTON);
	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(noticeShow);
	this->addCtrl(startBookingBtn);
	this->addCtrl(cannelAppointmentBtn);
	this->addCtrl(returnBtn);

}

CAddorCannelAppointment::~CAddorCannelAppointment()
{
	
}

int CAddorCannelAppointment::doAction()
{
	switch(this->ctrlIndex)
	{
		case 3:
			return 1;
		case 4:
			return 2;
		case 5:
			return 3;
	}
}

void CAddorCannelAppointment::showWin()
{
	
	
	//��̬��ʾ��ǰʱ����ж�����
	int currentPeopleInt = 0; 
	
	list<CAppointment*>::iterator it = CData::appointmentList.begin();
	
	for(; it!= CData::appointmentList.end(); ++it)
	{
		if((*it)->getAppointmentTurns() == CData::selectedAppointment->getAppointmentTurns()&&
		   (*it)->getAppointmentTime()== CData::selectedAppointment->getAppointmentTime()&&
		   (*it)->getDoctorName()== CData::selectedAppointment->getDoctorName() &&
		   (*it)->getAppointmentStatusInt() ==1 &&
		   (*it)->getDepartment() == CData::selectedAppointment->getDepartment()
		   )
		{
			currentPeopleInt++;
		}
		
	} 
	string currentPeopleString = CTools::intToString(currentPeopleInt);
	CData::currentPeopleInOneTime = currentPeopleInt;
	this->noticeLabel->setContent("��ǰ�����Ŷ�" + currentPeopleString + "��!!!");
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		
}








