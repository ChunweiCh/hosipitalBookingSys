#include "CPatientWin.h"






CPatientWin::CPatientWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	this->title = new CLabel(16,1,0,0,"�û�������",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"��ӭ,��ͨ�û�",LABEL);
	this->timeShow = new CLabel(28,4,0,0,"����: ",LABEL);
	
	this->personalCenBtn =new CButton(8,8,12,3,"��������",BUTTON);
	this->bookingManageBtn = new CButton(28,8,12,3,"ԤԼ����",BUTTON);
	this->startBookingBtn = new CButton(8,11,12,3,"  ȡ��  ",BUTTON);
	this->medicalConsultationBtn = new CButton(28,11,12,3,"������Ϣ",BUTTON);
	this->quitBtn = new CButton(8,14,12,3,"  �˳�  ",BUTTON);
	
	
	this->addCtrl(title);
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShow);
	this->addCtrl(personalCenBtn); //3
	this->addCtrl(bookingManageBtn);//4
	this->addCtrl(startBookingBtn);//5
	this->addCtrl(medicalConsultationBtn);//6
	this->addCtrl(quitBtn);//7
}


CPatientWin::~CPatientWin()
{
	
}




CPatientWin::doAction()
{
	switch(this->ctrlIndex)
	{
		//�������� 
		case 3:
			return PATIENTCENTERWIN;
		//ԤԼ���� 
		case 4:
			return PATIENTBOOKINGMANAGEWIN;
		//ȡ�� 
		case 5:
			return STARTAPPOINTMENTWIN;
		//������Ϣ 
		case 6:
			return TREATMENTWIN;
		//�˳� 
		case 7:
			{
				//��¼��ǰ�û���ԤԼ��ϢҪ��� 
				
				CData::nowUserAppointment.clear(); 
				//���nowUser;
				CData::nowUser=NULL;
				CData::selectedAppointment=NULL; 
				 
			}
			return MAINWIN; 

	} 
	return PATIENTWIN;
}



void CPatientWin::showWin()
{		
	string welcomeNotice = "��ӭ ";
	
	if(CData::nowUser != NULL)
	{
		welcomeNotice += CData::nowUser->getUserName();
	} 
	welcomeNotice += ", ��ͨ�û�";
	this->noticeLabel->setContent(welcomeNotice);
	//չʾʱ��
	this->timeShow->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
		

	
}













