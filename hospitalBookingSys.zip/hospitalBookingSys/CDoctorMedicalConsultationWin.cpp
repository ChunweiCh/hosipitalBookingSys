#include "CDoctorMedicalConsultationWin.h"


CDoctorMedicalConsultationWin::CDoctorMedicalConsultationWin(int x, int y, int w, int h)
:WinBase(x,y,w,h)
{
	
	this->title = new CLabel(26,1,0,0,"������Ϣ����",LABEL);
	this->noticeLabel = new CLabel(3,4,0,0,"",LABEL);
	this->timeShowLabel = new CLabel(38,4,0,0,"����: ",LABEL);
	
	this->upDownPageNoticeLabel = new CLabel(37,19,0,0,"�� �� �� ��ҳ",LABEL);

	//��ͷ
	this->tableHead = tableHead;
	tableHead.push_back("   ���   ");
	tableHead.push_back("   �����û�ID     ");
	tableHead.push_back("   ״̬  ");
	
	this->treatmentTable = new CTable(7,8,0,0,"",TABLE,tableHead); 
	
	this->row1Btn = new CButton(2,10,0,0,"",BUTTONDYNAMIC);
	this->row2Btn = new CButton(2,12,0,0,"",BUTTONDYNAMIC);
	this->row3Btn = new CButton(2,14,0,0,"",BUTTONDYNAMIC);

	this->returnBtn = new CButton(6,19,10,3,"����",BUTTON); 
	
	this->addCtrl(title); 
	this->addCtrl(noticeLabel);
	this->addCtrl(timeShowLabel);
	this->addCtrl(upDownPageNoticeLabel);

	this->addCtrl(treatmentTable);//7
	
	this->addCtrl(row1Btn);//5
	this->addCtrl(row2Btn);//6
	this->addCtrl(row3Btn);//7
	this->addCtrl(returnBtn); //8
	
	
}




CDoctorMedicalConsultationWin::~CDoctorMedicalConsultationWin()
{
	
}
	
int CDoctorMedicalConsultationWin::doAction()
{
	switch(this->ctrlIndex)
	{
		case 5:
		
		case 6:
		
		case 7: 
		{
			
		    // ǿ�����÷�ҳ��������ȫ��ʩ��
			    if(this->treatmentTable->getPageIndex() <= 0) {
			        this->treatmentTable->setPageIndex(1);
			    }
		    // ��ȡ��ǰҳ��3��ҽ������
		    list<CAppointment*> currentPageAppointment = this->treatmentTable->getCurrentPageAppointment(CData::appointmentList);/////////
		    
		    // ����ѡ�е������� (9��0, 10��1, 11��2)
		    int selectedRow = this->ctrlIndex - 5;
		    
		    // ��ȡѡ�е�ҽ��
		    list<CAppointment*>::iterator it = currentPageAppointment.begin();
		    advance(it, selectedRow);
		    
		    if (it != currentPageAppointment.end() && *it != NULL) 
			{	
				CData::selectedAppointment = NULL;
				list<CAppointment*>::iterator it2;
				for(it2 = CData::appointmentList.begin(); it2 != CData::appointmentList.end(); ++it2)
				{	
					if((*it2)->getAppointmentId() == (*it)->getAppointmentId())
					{
						CData::selectedAppointment = *it2;
						break;
					} 
						
				} 
		        if(!CData::selectedAppointment)
		        {//����δ�ҵ������ 
		        	return DOCTORMEDICALCONSULTATIONWIN;
				}
		        
		        //ҵ���߼�  
				return RECORDINGWIN;
		       

		    }
		    
		    return DOCTORMEDICALCONSULTATIONWIN;
		}
		//����	
		case 8:
			return DOCTORWIN;
		case -2:
			return DOCTORMEDICALCONSULTATIONWIN;
	}
	
	
	
}
	
void CDoctorMedicalConsultationWin::showWin()
{
	
	string welcomeNotice = "��ӭ ";
	if(CData::nowDoctor != NULL)
	{
		welcomeNotice += CData::nowDoctor->getUserName();
	} 
	welcomeNotice += ", ҽ��";
	this->noticeLabel->setContent(welcomeNotice);
	
	//չʾʱ��
	this->timeShowLabel->setContent("����: "+CTools::getCurrentTime()); 
	
	CTools::paintWindow(this->x,this->y,this->width,this->height);
	
	for(int i =0;i<this->ctrlCount;i++)
	{
		this->ctrlArr[i]->show(); 

	}
	

	this->treatmentTable->showDocTreatmentData(CData::appointmentList);	
	this->treatmentTable->showPage(3,CData::appointmentList.size());

	

}


	

void CDoctorMedicalConsultationWin::winRun()
{
	int i=0, key= 0;
  
    
    // �ҵ���ʼ�۽��Ŀؼ�
    for (i=0; i<this->ctrlCount; i++)
    {
        if (this->ctrlArr[i]->getCtrlType() == EDIT)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                          this->ctrlArr[i]->getY()+1);
            break;
        }
        else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                 this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
        {
            CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
            // Set arrow immediately for dynamic buttons
            if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
            {
                static_cast<CButton*>(this->ctrlArr[i])->setContent("��");
                this->ctrlArr[i]->show();
                
            }
            break;
        }
    }
    
    // ���浱ǰ�۽����а�ťָ��
    CButton* currentRowBtn = NULL;
    if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
    {
        currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
    }
    // ������������ 
    while (1)
    {
        key = CTools::getKey();
        switch(key)
        {
            case KEY_DOWN:
            {	
            	// �����ǰ�а�ť�ļ�ͷ
                if (currentRowBtn != NULL)
                {
                    currentRowBtn->setContent("");
                    currentRowBtn->show();
                    currentRowBtn = NULL;
                }
                
                i++;
                if (i == this->ctrlCount) i = 0;
                
                while(1)
                {
                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
                    {	
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
                                      this->ctrlArr[i]->getY()+1);
                        break;
                    }
                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
                    {
                    	
                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
                        // ������а�ť����ʾ��ͷ
                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
                        {
                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
                            currentRowBtn->setContent("��");
                            currentRowBtn->show();
                            showWin();
                        }
                        break;
                    }
                    i++;
                    if (i == this->ctrlCount) i = 0;
                }
                break;
			}
				    
                
                
            case KEY_UP:
                {	
                	// �����ǰ�а�ť�ļ�ͷ
	                if (currentRowBtn != NULL)
	                {
	                    currentRowBtn->setContent("");
	                    currentRowBtn->show();
	                    currentRowBtn = NULL;
	                }
                	i--;
	                if (i < 0) i = this->ctrlCount - 1;
	                
	                while(1)
	                {
	                    if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+2+this->ctrlArr[i]->getContent().size(),
	                                      this->ctrlArr[i]->getY()+1);
	                        break;
	                    }
	                    else if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
	                             this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                    {	
	                    	
	                        CTools::gotoxy(this->ctrlArr[i]->getX()+3, this->ctrlArr[i]->getY()+1);
	                         // ������а�ť����ʾ��ͷ
	                        if (this->ctrlArr[i] == row1Btn || this->ctrlArr[i] == row2Btn || this->ctrlArr[i] == row3Btn)
	                        {
	                            currentRowBtn = static_cast<CButton*>(this->ctrlArr[i]);
	                            currentRowBtn->setContent("��");
	                            currentRowBtn->show();
	                            showWin();
	                        }
	                        
	                        break;
	                    }
	                    i--;
	                    if (i < 0) i = this->ctrlCount - 1;
	                }
	                break;
				}
                
                
                
            case KEY_RIGHT:
            	{
            		this->treatmentTable->showNextPage();
	                this->ctrlIndex = -2;
	                return;
				}
                
                
            case KEY_LEFT:
                this->treatmentTable->showLastPage();
                this->ctrlIndex = -2;
                return;
                
            case KEY_ENTER:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == BUTTON || 
                    this->ctrlArr[i]->getCtrlType() == BUTTONDYNAMIC)
	                {
	                    this->ctrlIndex = i;
	                    return;
	                }
	                break;
				}
                
                
            default:
            	{
            		if (this->ctrlArr[i]->getCtrlType() == EDIT)
	                {    
	                    static_cast<CEdit*>(ctrlArr[i])->editKeyListen((char)key);
	                }
	                break;
				}
                
        }
    }
}
