#ifndef _CRECORDINGWIN_H_
#define _CRECORDINGWIN_H_




#include "windowBase.h"
#include "ctrlBase.h"


#include "CData.h"


// ҽ�������� --������Ϣ--�����¼ 
class CRecordingWin :public WinBase
{
	public:
		CRecordingWin();
		CRecordingWin(int x, int y, int w, int h);
		~CRecordingWin();
		
			
		void showWin(); 
		int doAction();
		
		
	private:
	
	CLabel* title;
	CLabel* noticeLabel;
	CLabel* timeShowLabel;
	
	CLabel* patientIdLabel;
	CLabel* patientIdShow;
	CLabel* appointmentPatientDesLabel;
	CLabel* doctorDescriptionLabel;
	
	CEdit* appointmentPatientDesEdit;
	CEdit* doctorDescriptionEdit;
	
	CButton* confirmBtn;
	CButton* returnBtn;
	bool editFlag;
	
		
};








#endif
