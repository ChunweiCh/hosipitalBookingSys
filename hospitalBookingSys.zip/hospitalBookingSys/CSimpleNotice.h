#ifndef _CSIMPLENOTICE_H
#define _CSIMPLENOTICE_H


#include "windowBase.h"
#include "ctrlBase.h"
#include "CData.h"

#include <string>


class CSimpleNotice: public WinBase
{
	public:
		CSimpleNotice();
		CSimpleNotice(int x, int y, int w, int h,string noticeShow);
		~CSimpleNotice(); 
		int doAction();
		void showWin();
		
	private:
		CLabel* title;
		CLabel* noticeLabel;
		
		
		CButton* startBookingBtn;
		CButton* cannelAppointmentBtn;
		CButton* returnBtn; 
	
		string noticeShow;
	
};



#endif
