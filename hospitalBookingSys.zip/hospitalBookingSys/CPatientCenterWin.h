#ifndef _CPATIENTCENTERWIN_H_
#define _CPATIENTCENTERWIN_H_


#include "windowBase.h"
#include "ctrlBase.h"

#include "CData.h"

class CPatientCenterWin : public WinBase
{	
	public:
		CPatientCenterWin();
		CPatientCenterWin(int x, int y, int w, int h);
		~CPatientCenterWin(); 
		void showWin();
		int doAction();
	private:
	CLabel* title;
	CLabel* noticeLabel;//��ӭ���û�������ͨ�û� 
	CLabel* timeShow;//���ڵ�ʱ��
	
	CButton* userInfoBtn;
	CButton* changePwdBtn;
	CButton* returnBtn;
	

		
		
	
};




#endif
